import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.black54;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // ─── TEMA HIJAU KERANG ─────────────────────────────
static const Color bgMain    = Color(0xFFF1F8F5);
static const Color bgCard    = Color(0xFFE7F3EE);
static const Color bgSurface = Color(0xFFFFFFFF);

static const Color accentBlue = Color(0xFF16856B);
static const Color textMain   = Color(0xFF17231E);
static const Color textSub    = Color(0xFF65756D);

  // ─── FITUR DARI DASHBOARD ─────────────────────────────────────────────
  final List<Map<String, dynamic>> featuresList = [
  {
    "title": "WhatsApp Crash",
    "icon": Icons.bug_report_rounded,
    "color": const Color(0xFF16856B),
    "desc":
        "Kemampuan mengirimkan payload secara masif ke target Private (Nomor) maupun Global (Grup) dengan hit rate tinggi dan efisiensi waktu.",
  },
  {
    "title": "Bug Sender",
    "icon": Icons.devices_rounded,
    "color": const Color(0xFF229A7A),
    "desc":
        "Pairing & konfigurasi perangkat sender untuk manajemen sesi pengiriman payload yang lebih terstruktur dan efisien.",
  },
  {
    "title": "Riwayat Aktivitas",
    "icon": Icons.history_rounded,
    "color": const Color(0xFF2EAA88),
    "desc":
        "Rekam dan pantau seluruh histori aktivitas akun kamu secara real-time, lengkap dengan log pengiriman dan status operasi.",
  },
  {
    "title": "Profile & Akun",
    "icon": Icons.person_rounded,
    "color": const Color(0xFF147A62),
    "desc":
        "Kelola data profil, ubah password, dan pantau status akun serta masa aktif langganan kamu dengan mudah.",
  },
  {
    "title": "Global Chat",
    "icon": Icons.groups_2_rounded,
    "color": const Color(0xFF45B89A),
    "desc":
        "Ruang komunitas eksklusif untuk berdiskusi, berbagi pengalaman, dan berinteraksi langsung dengan seluruh pengguna LOL PROJECT.",
  },
];

  // ─── KEBIJAKAN (sama seperti sebelumnya, branding diganti LOL) ─────
  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc":
          "Akun eksklusif LOL PROJECT tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc":
          "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc":
          "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc":
          "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc":
          "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
    },
  ];

  // ──────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http.get(Uri.parse(
          'http://freepanelbygua.panel-xsat.my.id:3655/getServerInfo?key=${widget.sessionKey}'));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer =
        Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse(
              'http://freepanelbygua.panel-xsat.my.id:3655/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs   = duration;
          if (duration < 200) {
  apiStatusColor = const Color(0xFF16856B);
} else if (duration < 500) {
  apiStatusColor = const Color(0xFFD9A441);
} else {
  apiStatusColor = const Color(0xFFC66A4A);
}
          apiStatusText = "Sys.Online :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline    = false;
          apiPingMs      = 0;
          apiStatusColor = const Color(0xFFD32F2F);
          apiStatusText  = "Sys.Offline :: DEST";
        });
      }
    }
  }

  // ─── BANNER ────────────────────────────────────────────────────────────
  Widget _buildBanner() {
    return Container(
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 2.5)),
      ),
      child: SizedBox(
        height: 210,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/banner.jpg', fit: BoxFit.cover),
            // Dark gradient overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.25),
                    Colors.black.withOpacity(0.68),
                  ],
                ),
              ),
            ),
            // Teks tengah
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Info Queen",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      fontFamily: 'Aktura',
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    "Fitur Dan Kebijakan Queen",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      letterSpacing: 0.8,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── STATUS HEADER ─────────────────────────────────────────────────────
  Widget _buildStatusHeader() {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black, width: 1.5),
        boxShadow: const [
          BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (_, __) => Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: apiStatusColor,
                boxShadow: [
                  BoxShadow(
                    color: apiStatusColor.withOpacity(_glowAnimation.value * 0.6),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              apiStatusText.toUpperCase(),
              style: TextStyle(
                color: apiStatusColor == Colors.black54 ? textMain : apiStatusColor,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w800,
                fontSize: 13,
                letterSpacing: 1.5,
              ),
            ),
          ),
          Icon(Icons.memory, color: textSub.withOpacity(0.4), size: 20),
        ],
      ),
    );
  }

  // ─── SECTION HEADER (!!) ───────────────────────────────────────────────
  Widget _buildSectionHeader(String title, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.only(left: 10),
          decoration: const BoxDecoration(
            border: Border(
                left: BorderSide(color: Colors.black, width: 3.5)),
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.black87, size: 20),
              const SizedBox(width: 8),
              Text(
                "!! $title",
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: 60,
          height: 4,
          decoration: BoxDecoration(
              color: Colors.black87, borderRadius: BorderRadius.circular(2)),
        ),
      ],
    );
  }

  // ─── TENTANG LOL ────────────────────────────────────────────────────
  Widget _buildTentangSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader("Tentang Queen", Icons.info_outline_rounded),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.black, width: 1.5),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
            ],
          ),
          child: const Text(
            "Queen Project adalah sebuah sistem utilitas tingkat lanjut yang dirancang khusus untuk memfasilitasi pengujian stabilitas dan pengiriman payload (Bug Testing). Dibangun dengan arsitektur berkinerja tinggi, sistem ini menjamin kecepatan eksekusi, keamanan enkripsi sesi, dan presisi dalam pengiriman data baik secara personal maupun publik. Kami menyediakan infrastruktur server yang kuat untuk kelancaran tugas Anda.",
            style: TextStyle(
              color: Colors.black87,
              fontSize: 13,
              height: 1.75,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.justify,
          ),
        ),
      ],
    );
  }

  // ─── FEATURE CARD ──────────────────────────────────────────────────────
  Widget _buildFeatureCard(Map<String, dynamic> feature) {
    final Color c = feature['color'] as Color;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black, width: 1.5),
        boxShadow: const [
          BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: c.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: c.withOpacity(0.22), width: 1),
            ),
            child: Icon(feature['icon'] as IconData, color: c, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  feature['title'] as String,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  feature['desc'] as String,
                  style: const TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    height: 1.55,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── FITUR SECTION ─────────────────────────────────────────────────────
  Widget _buildFiturSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader("Fitur-fitur Utama", Icons.rocket_launch_rounded),
        const SizedBox(height: 14),
        ...featuresList.map(_buildFeatureCard).toList(),
      ],
    );
  }

  // ─── RULE CARD ─────────────────────────────────────────────────────────
  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black, width: 1.5),
        boxShadow: const [
          BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Theme(
        data: ThemeData(dividerColor: Colors.transparent),
        child: ExpansionTile(
          iconColor: accentBlue,
          collapsedIconColor: accentBlue.withOpacity(0.5),
          tilePadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: accentBlue.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentBlue.withOpacity(0.2)),
            ),
            child:
                Icon(rule['icon'] as IconData, color: accentBlue, size: 22),
          ),
          title: Text(
            rule['title'] as String,
            style: const TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.bold,
              fontSize: 13,
              fontFamily: 'Orbitron',
              letterSpacing: 0.8,
            ),
          ),
          children: [
            Container(
              padding: const EdgeInsets.only(
                  left: 20, right: 20, bottom: 18, top: 2),
              width: double.infinity,
              child: Text(
                rule['desc'] as String,
                style: const TextStyle(
                  color: Colors.black54,
                  fontSize: 12,
                  height: 1.55,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PENALTY BOX ───────────────────────────────────────────────────────
  Widget _buildPenaltyBox() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8, bottom: 28),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(18),
        border:
            Border.all(color: const Color(0xFFD32F2F), width: 1.5),
        boxShadow: const [
          BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(4, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.warning_amber_rounded,
                  color: Color(0xFFEF5350), size: 26),
              SizedBox(width: 10),
              Text(
                "VIOLATION PENALTY",
                style: TextStyle(
                  color: Color(0xFFEF5350),
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
            style: TextStyle(
                color: Colors.black87,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
                height: 1.5),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFFD32F2F).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: const Color(0xFFEF5350).withOpacity(0.5)),
            ),
            child: const Text(
              "AKUN AKAN DIHAPUS PERMANEN",
              style: TextStyle(
                  color: Colors.black87,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
            style: TextStyle(
              color: Color(0xFFEF5350),
              fontSize: 11,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        backgroundColor: bgMain,
        body: Center(
          child: CircularProgressIndicator(color: accentBlue),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgMain,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            // ── Banner full-width ──
            SliverToBoxAdapter(child: _buildBanner()),

            SliverPadding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // Status server
                  _buildStatusHeader(),

                  // Tentang LOL
                  _buildTentangSection(),
                  const SizedBox(height: 28),

                  // Fitur-fitur Utama
                  _buildFiturSection(),
                  const SizedBox(height: 28),

                  // Kebijakan Pengguna
                  _buildSectionHeader(
                      "Kebijakan Pengguna", Icons.shield_outlined),
                  const SizedBox(height: 14),
                  ...rulesList
                      .asMap()
                      .entries
                      .map((e) => _buildRuleCard(e.key, e.value))
                      .toList(),

                  // Penalty
                  _buildPenaltyBox(),

                  // Footer
                  Center(
                    child: Column(
                      children: [
                        const Icon(Icons.shield_moon_rounded,
                            color: Colors.black26, size: 28),
                        const SizedBox(height: 12),
                        const Text(
                          "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server Queen. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
                          style: TextStyle(
                            color: Colors.black38,
                            fontSize: 11,
                            fontStyle: FontStyle.italic,
                            fontFamily: 'ShareTechMono',
                            height: 1.55,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        Container(
                          height: 3,
                          width: 40,
                          decoration: BoxDecoration(
                            color: Colors.black26,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
