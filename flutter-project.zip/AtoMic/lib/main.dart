import 'package:flutter/material.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'set.dart';
import 'tap.dart';
import 'landing_page.dart';
import 'owner_page.dart'; // <--- Import OwnerPage

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QUEEN PROJECT',
      theme: ThemeData(
  brightness: Brightness.dark,
  fontFamily: 'ShareTechMono',

  scaffoldBackgroundColor: const Color(0xFFE8F5E9),

  colorScheme: const ColorScheme.dark().copyWith(
    primary: const Color(0xFF00A86B),      // Hijau utama
    secondary: const Color(0xFF66BB6A),    // Hijau secondary
    background: const Color(0xFFE8F5E9),
    surface: const Color(0xFFF1F8F4),
  ),

  primaryColor: const Color(0xFF00A86B),

  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFFE8F5E9),
    foregroundColor: Colors.black87,
    iconTheme: IconThemeData(
      color: Colors.black87,
    ),
    elevation: 0,
  ),

  iconTheme: const IconThemeData(
    color: Colors.black87,
  ),

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF00A86B),
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
    ),
  ),

  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: const Color(0xFF007A4D),
    ),
  ),

  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: const Color(0xFF007A4D),
      side: const BorderSide(
        color: Color(0xFF00A86B),
      ),
    ),
  ),

  floatingActionButtonTheme:
      const FloatingActionButtonThemeData(
    backgroundColor: Color(0xFF00A86B),
    foregroundColor: Colors.white,
  ),

  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: const Color(0xFFF1F8F4),

    focusedBorder: OutlineInputBorder(
      borderSide: const BorderSide(
        color: Color(0xFF00A86B),
        width: 2,
      ),
      borderRadius: BorderRadius.circular(12),
    ),

    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(
        color: const Color(0xFF00A86B).withOpacity(0.5),
      ),
      borderRadius: BorderRadius.circular(12),
    ),
  ),

  snackBarTheme: const SnackBarThemeData(
    backgroundColor: Color(0xFF007A4D),
    contentTextStyle: TextStyle(
      color: Colors.white,
    ),
  ),
),
      
            
      // Global Touch Wrapper
      builder: (context, child) {
        return GlobalTouchWrapper(
          child: child!,
        );
      },

      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => LandingPage());
          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());
          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(
                keyToken: args['keyToken'], // Pastikan keyToken ada di args
              ),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'], // Pastikan sessionKey ada di args
              ),
            );

        // --- ROUTE BARU: OWNER ---
          case '/owner':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => OwnerPage(
                sessionKey: args['sessionKey'], // Pastikan sessionKey ada di args
                username: args['username'], // Pastikan username ada di args
              ),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Center(child: Text("404 - Not Found")),
              ),
            );
        }
      },
    );
  }
}