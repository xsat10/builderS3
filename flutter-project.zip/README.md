# Gaana Player Android Project

A small Android music player project. It lets the user choose an audio file from device storage and play, pause, or stop it.

## Build debug APK
1. Open this project in Android Studio (JDK 17 recommended).
2. Let Gradle sync and download dependencies.
3. Run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The POSIX `gradlew` launcher is packaged with executable permission. If your bot extracts ZIP files without preserving Unix permissions, run `chmod +x gradlew` before `./gradlew assembleDebug`.
