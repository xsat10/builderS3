# BotMD App

Build APK:
```
flutter pub get
flutter build apk --release
```

APK: build/app/outputs/app-release.apk

Features: Login, Pairing, Dashboard
Server: http://private-one.jhonaleystore.id:2150
