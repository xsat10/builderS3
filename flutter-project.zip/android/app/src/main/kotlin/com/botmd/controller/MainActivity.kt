package com.botmd.controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
