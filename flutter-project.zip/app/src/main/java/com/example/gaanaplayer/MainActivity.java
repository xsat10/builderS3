package com.example.gaanaplayer;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 1001;
    private MediaPlayer player;
    private TextView statusText;
    private Uri selectedSong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button chooseButton = findViewById(R.id.chooseButton);
        Button playButton = findViewById(R.id.playButton);
        Button stopButton = findViewById(R.id.stopButton);

        chooseButton.setOnClickListener(v -> chooseAudio());
        playButton.setOnClickListener(v -> togglePlayback());
        stopButton.setOnClickListener(v -> stopPlayback());
    }

    private void chooseAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        startActivityForResult(intent, PICK_AUDIO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO && resultCode == RESULT_OK && data != null) {
            selectedSong = data.getData();
            if (selectedSong != null) {
                getContentResolver().takePersistableUriPermission(
                    selectedSong, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String name = selectedSong.getLastPathSegment();
                statusText.setText("Selected song:\n" + (name == null ? "Audio file" : name));
                preparePlayer();
            }
        }
    }

    private void preparePlayer() {
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setDataSource(this, selectedSong);
            player.setOnPreparedListener(mp -> {
                statusText.setText("Ready to play");
                mp.start();
            });
            player.setOnCompletionListener(mp -> statusText.setText("Song finished"));
            player.setOnErrorListener((mp, what, extra) -> {
                statusText.setText("Couldn't play this audio file.");
                releasePlayer();
                return true;
            });
            statusText.setText("Loading song…");
            player.prepareAsync();
        } catch (IOException | IllegalArgumentException e) {
            statusText.setText("Couldn't open this audio file.");
            releasePlayer();
        }
    }

    private void togglePlayback() {
        if (player == null) {
            if (selectedSong == null) {
                Toast.makeText(this, "Pehle audio file choose karein", Toast.LENGTH_SHORT).show();
            } else {
                preparePlayer();
            }
            return;
        }
        if (player.isPlaying()) {
            player.pause();
            statusText.setText("Paused");
        } else {
            try {
                player.start();
                statusText.setText("Playing");
            } catch (IllegalStateException e) {
                preparePlayer();
            }
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
            } catch (IllegalStateException ignored) { }
            releasePlayer();
            statusText.setText("Stopped — choose a song to play again.");
        }
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
