import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:carousel_slider/carousel_slider.dart' as carousel;
import 'package:flutter_animate/flutter_animate.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'spam_pair.dart';
import 'custom_payload.dart';
import 'bug_group_page.dart';
import 'thanks_to_page.dart';
import 'tes_func_page.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF0D1117);
const Color kCard    = Color(0xFF161B22);
const Color kCardAlt = Color(0xFF1C2333);
const Color kBorder  = Color(0xFF30363D);
const Color kCyan    = Color(0xFF00E5FF);
const Color kGreen   = Color(0xFF00E676);
const Color kPink    = Color(0xFFE91E8C);
const Color kOrange  = Color(0xFFFF6D00);
const Color kBlue    = Color(0xFF2979FF);
const Color kPurple  = Color(0xFF7C4DFF);
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;
const Color kRed     = Color(0xFFFF1100);  // ← TAMBAHKAN INI

// ─── WELCOME NOMERCY ANIMATED SPLASH/INTRO ─────────────────────────────────────
class WelcomeNoMercyIntro extends StatefulWidget {
  final VoidCallback onFinished;
  const WelcomeNoMercyIntro({super.key, required this.onFinished});

  @override
  State<WelcomeNoMercyIntro> createState() => _WelcomeNoMercyIntroState();
}

class _WelcomeNoMercyIntroState extends State<WelcomeNoMercyIntro>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    _scaleAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _controller.forward();

    // Auto finish after animation
    Timer(const Duration(milliseconds: 3200), () {
      if (mounted) {
        widget.onFinished();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          CustomPaint(
            size: Size.infinite,
            painter: _GridPatternPainter(
              gridColor: kRed.withOpacity(0.05),
              lineColor: kCyan.withOpacity(0.02),
              spacing: 30,
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: ScaleTransition(
                scale: _scaleAnim,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kRed.withOpacity(0.15),
                        border: Border.all(color: kRed.withOpacity(0.6), width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: kRed.withOpacity(0.4),
                            blurRadius: 30,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: const Icon(
                        FontAwesomeIcons.skull,
                        size: 54,
                        color: kRed,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'WELCOME TO',
                      style: TextStyle(
                        color: kWhite54,
                        fontSize: 14,
                        fontFamily: 'Orbitron',
                        letterSpacing: 4,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [kRed, kOrange, kYellow],
                      ).createShader(bounds),
                      child: const Text(
                        'NEKO VERSE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 3,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kBorder),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.code_rounded, color: kCyan, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            'Credit by RYUNA',
                            style: TextStyle(
                              color: kWhite.withOpacity(0.8),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Prayer Time Service ───────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFFF59E0B);
    case 'admin':    return const Color(0xFFEF4444);
    case 'reseller': return kGreen;
    case 'vip':      return kPurple;
    default:         return kCyan;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── HEXAGON PATTERN PAINTER (Fixed - mirip gambar asli) ──────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kCyan.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;  // lebar diamond
    const double h = 52.0;  // tinggi diamond

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)   // top
      ..lineTo(center.dx + hw, center.dy)   // right
      ..lineTo(center.dx, center.dy + hh)   // bottom
      ..lineTo(center.dx - hw, center.dy)   // left
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()..color = gridColor..strokeWidth = 0.8..style = PaintingStyle.stroke;
    final paintLines = Paint()..color = lineColor..strokeWidth = 0.4..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paintLines);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paintLines);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  // Intro Splash flag
  bool _showIntro = true;
  
  // ⭐ TAMBAHKAN INI DI BAWAH _showIntro
  int _carouselCurrentIndex = 0;

  // ── Animation controllers ─────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // Online Users polling
  Timer? _statsTimer;

  // News carousel
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  // Quick Actions carousel
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  // ── Location ──
  bool _locationLoading = false;
  bool _locationGranted = false;

  // ── Prayer times ──
  String _prayerCity = 'Surabaya';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer(); 
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
  channel = WebSocketChannel.connect(Uri.parse('http://nodepterodacly.raraa.lol:8440'));

  // Kirim validate dulu, stats menyusul setelah delay
  channel.sink.add(jsonEncode({
    'type': 'validate',
    'key': sessionKey,
    'androidId': androidId,
  }));

  channel.stream.listen((event) {
    final data = jsonDecode(event);

    // Setelah validate sukses, baru minta stats pertama kali
    if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    }

    if (data['type'] == 'stats' && mounted) {
      setState(() {
        onlineUsers = data['onlineUsers'] ?? 0;
        activeConns = data['activeConnections'] ?? 0;
      });
    }

    // Handle force logout
    if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Session invalid');
    }

    if (data['type'] == 'forceLogout' && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Logged out');
    }
  }, onError: (_) {
    // Reconnect kalau putus
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) _connectWS();
    });
  });

  // Polling setiap 5 detik
  _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
    try {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    } catch (_) {}
  });
}

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ── Fetch Prayer Times ────────────────────────────────────────────────────
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  // ── Detect Location ───────────────────────────────────────────────────────
  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      // Ambil koordinat
      final position = await Geolocator.getCurrentPosition(
  desiredAccuracy: LocationAccuracy.medium,
);

      // Konversi koordinat -> nama kota
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  // ── Fetch Hadith ──────────────────────────────────────────────────────────
  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  // ── Change City Dialog ────────────────────────────────────────────────────
  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false; // reset icon lokasi
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Hadith Full Dialog ────────────────────────────────────────────────────
  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kCyan.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kCyan.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kCyan.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kCyan.withOpacity(0.2)),
                      child: const Icon(Icons.menu_book_rounded, color: kCyan, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kCyan, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded, color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF1A1F2E),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kCyan)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: kCyan, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF141824),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kCyan.withOpacity(0.5)),
                          color: kCyan.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kCyan, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kCyan, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kCyan)),
          ),
        ],
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _onNavTap(int index) {
  setState(() => _navIndex = index);
  if (index == 0) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_newsPageCtrl.hasClients) {
        setState(() {
          _currentNewsPage = 0.0;
          _newsPageViewKey++;
        });
        _newsPageCtrl.jumpToPage(0);
      }
    });
  }
}

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  // ── Current Page ──────────────────────────────────────────────────────────
Widget _buildCurrentPage() {
  switch (_navIndex) {
    case 0:
      return _buildHomePage();
    case 1:
      return _buildChatMenuPage();  // Chat menu (SPAM PAIR, CRASH, CUSTOM BUG)
    case 2:
      return BugGroupPage(          // Group → Bug Group Page
        sessionKey: sessionKey,
        role: role,
      );
    case 3:
      return InfoPage(sessionKey: sessionKey);  // info → Info Page
    case 4:
      return ToolsPage(             // Tools → Tools Page
        sessionKey: sessionKey, 
        userRole: role, 
        listDoos: listDoos
      );
    default:
      return _buildHomePage();
  }
}

  // ── HOME PAGE ─────────────────────────────────────────────────────────────
  Widget _buildHomePage() {
  return FadeTransition(
    opacity: _fadeAnim,
    child: SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── BANNER VIDEO (TETAP SAMA) ────────────────────
          _buildBannerVideo(),           // ← TETAP SAMA, TIDAK DIUBAH
          const SizedBox(height: 14),
          
          // ─── THANKS TO (BARU) ─────────────────────────────
          _buildThanksToBanner(),        // ← TAMBAHKAN INI
          const SizedBox(height: 14),
          
          // ─── WELCOME CARD ─────────────────────────────────
          _buildWelcomeCard(),
          const SizedBox(height: 14),
          
          // ─── SENDER & TOOLS ──────────────────────────────
          _buildSenderAndToolsSection(),
          const SizedBox(height: 14),
          
          // ─── QUICK ACTIONS ───────────────────────────────
          _buildQuickActionsSection(),
          const SizedBox(height: 14),
          
          // ─── LATEST UPDATES ──────────────────────────────
          _buildLatestUpdates(),
          const SizedBox(height: 14),
          
          // ─── PRAYER SECTION ──────────────────────────────
          _buildPrayerSection(),
          const SizedBox(height: 14),
          
          // ─── HADITH SECTION ──────────────────────────────
          _buildHadithSection(),
          const SizedBox(height: 24),
          
          Center(
            child: Text('NEKOVERSE',
              style: TextStyle(
                color: Colors.white.withOpacity(0.12),
                fontSize: 13, letterSpacing: 4,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    ),
  );
}

// ─── ANIMATED BACKGROUND WIDGET ──────────────────────────────────────────
Widget AnimatedBackground() {
  return Container(
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF071A19),
          Color(0xFF0A2220),
          Color(0xFF0D2E2C),
          Color(0xFF0A1D1C),
        ],
      ),
    ),
    child: CustomPaint(
      painter: _GridPatternPainter(
        gridColor: kCyan.withOpacity(0.03),
        lineColor: kGreen.withOpacity(0.02),
        spacing: 30,
      ),
    ),
  );
}
  
// ════════════════════════════════════════════════════════════════════════════
// 🔥 CHAT MENU PAGE — Dengan Animasi Carousel (Sama seperti Dashboard)
// ════════════════════════════════════════════════════════════════════════════
Widget _buildChatMenuPage() {
  final List<Map<String, dynamic>> chatMenus = [
    {
      'title': 'SPAM PAIR',
      'subtitle': 'Pairing WA & OTP TG',
      'description': 'Pairing Whatsapp dan OTP Telegram',
      'icon': FontAwesomeIcons.whatsapp,
      'gradient': [const Color(0xFFFF512F), const Color(0xFFF09819)],
      'badge': 'SPAM',
      'badgeColor': const Color(0xFFFF9800),
      'features': ['Mudah Digunakan', 'Anti Gimmick', 'Tanpa Sender'],
      'page': SpamPairPage(
        sessionKey: sessionKey,
        username: username,
        role: role,
      ),
    },
    {
      'title': 'CRASH',
      'subtitle': 'Hanya Bug',
      'description': 'Gunakan langsung dengan cepat',
      'icon': FontAwesomeIcons.bug,
      'gradient': [const Color(0xFF075E54), const Color(0xFF25D366)],
      'badge': 'RECOMMENDED',
      'badgeColor': const Color(0xFFFF6B35),
      'features': ['Mudah digunakan', 'Function terbaru', 'All work gacor'],
      'page': HomePage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      ),
    },
    {
      'title': 'CUSTOM BUG',
      'subtitle': 'Menu custom bug',
      'description': 'Buat menu bug, delay pengiriman dan loops',
      'icon': Icons.settings_applications,
      'gradient': [const Color(0xFF6A11CB), const Color(0xFF2575FC)],
      'badge': 'CUSTOM',
      'badgeColor': const Color(0xFF9C27B0),
      'features': ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
      'page': CustomPayloadPage(
        sessionKey: sessionKey,
        username: username,
        role: role,
        listBug: listBug,
      ),
    },
    // ─── ⭐ TEST FUNC ──────────────────────────────────
    {
      'title': 'TEST FUNC',
      'subtitle': 'Custom Function',
      'description': 'Kirim function custom dengan delay & loops',
      'icon': Icons.functions_rounded,
      'gradient': [const Color(0xFFE91E63), const Color(0xFF9C27B0)],
      'badge': 'NEW',
      'badgeColor': const Color(0xFFE91E63),
      'features': ['Custom Function', 'Atur Delay', 'Support Loops'],
      'page': TesFuncPage(
        sessionKey: sessionKey,
        username: username,
        role: role,
      ),
    },
  ];

  return Scaffold(
    backgroundColor: Colors.transparent,
    body: Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF071A19),
            Color(0xFF0A2220),
            Color(0xFF0D2E2C),
            Color(0xFF0A1D1C),
          ],
        ),
      ),
      child: Stack(
        children: [
          Positioned.fill(child: AnimatedBackground()),
          // Subtle top glow
          Positioned(
            top: -60,
            left: -60,
            right: -60,
            height: 300,
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topCenter,
                  radius: 1.0,
                  colors: [Color(0xFF25D366).withOpacity(0.12), Colors.transparent],
                ),
              ),
            ),
          ),
          Column(
            children: [
              _buildChatHeader(),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(top: 8, bottom: 16),
                  child: Column(
                    children: [
                      // ─── // ─── CAROUSEL SLIDER ──────────────────────
Expanded(
  child: carousel.CarouselSlider.builder(
    options: carousel.CarouselOptions(
      height: double.infinity,
      viewportFraction: 0.82,
      initialPage: 0,
      enableInfiniteScroll: true,
      autoPlay: true,
      autoPlayInterval: Duration(seconds: 4),
      autoPlayAnimationDuration: Duration(milliseconds: 700),
      autoPlayCurve: Curves.easeInOutCubic,
      enlargeCenterPage: true,
      scrollDirection: Axis.horizontal,
      onPageChanged: (index, reason) {
        setState(() { _carouselCurrentIndex = index; });
      },
    ),
    itemCount: chatMenus.length,
    itemBuilder: (context, index, realIndex) {
      return _buildChatCarouselCard(chatMenus[index], index);
    },
  ),
),
                      SizedBox(height: 16),
                      // ─── DOT INDICATORS ──────────────────────
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(chatMenus.length, (i) {
                          final bool active = i == _carouselCurrentIndex;
                          return AnimatedContainer(
                            duration: Duration(milliseconds: 300),
                            margin: EdgeInsets.symmetric(horizontal: 4),
                            width: active ? 24 : 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: active
                                  ? Color(0xFF25D366)
                                  : Colors.white.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(4),
                              boxShadow: active
                                  ? [BoxShadow(color: Color(0xFF25D366).withOpacity(0.6), blurRadius: 6)]
                                  : [],
                            ),
                          );
                        }),
                      ),
                      SizedBox(height: 16),
                      // ─── INFO PANEL ──────────────────────────
                      _buildChatInfoPanel(),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

// ─── CHAT HEADER ──────────────────────────────────────────────────────────
Widget _buildChatHeader() {
  return Container(
    height: 175,
    width: double.infinity,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF075E54),
          Color(0xFF0A7A6E),
          Color(0xFF071A19).withOpacity(0.0),
        ],
        stops: [0.0, 0.6, 1.0],
      ),
    ),
    child: Stack(
      children: [
        Positioned.fill(
          child: Opacity(
            opacity: 0.04,
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/logo.jpg'),
                  repeat: ImageRepeat.repeat,
                  scale: 2.5,
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 0, left: 0, right: 0,
          height: 40,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Color(0xFF071A19)],
              ),
            ),
          ),
        ),
        Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xFF25D366).withOpacity(0.45),
                      blurRadius: 22,
                      spreadRadius: 4,
                    ),
                  ],
                  border: Border.all(color: Colors.white.withOpacity(0.25), width: 2),
                ),
                child: Center(
                  child: Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 36),
                ),
              ),
              SizedBox(height: 10),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [Color(0xFF25D366), Color(0xFFB2DFDB)],
                ).createShader(bounds),
                child: Text(
                  "NEKOVERSE MENU",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                  ),
                ),
              ),
              SizedBox(height: 4),
              Text(
                "Pilih menu yang tersedia bosque!",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.65),
                  fontSize: 12,
                  letterSpacing: 0.5,
                ),
              ),
              SizedBox(height: 10),
              Container(
                width: 100,
                height: 2.5,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Color(0xFF25D366), Colors.transparent],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

// ─── CHAT CAROUSEL CARD ──────────────────────────────────────────────────
Widget _buildChatCarouselCard(Map<String, dynamic> menu, int index) {
  final gradient = menu['gradient'] as List<Color>;
  final features = menu['features'] as List<String>;

  return Animate(
    effects: [
      FadeEffect(duration: 350.ms, delay: (80 * index).ms),
      SlideEffect(
        begin: Offset(0, 0.04),
        end: Offset.zero,
        duration: 350.ms,
        delay: (80 * index).ms,
        curve: Curves.easeOut,
      ),
    ],
    child: GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => menu['page'],
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradient,
          ),
          boxShadow: [
            BoxShadow(
              color: gradient[0].withOpacity(0.45),
              blurRadius: 28,
              spreadRadius: 0,
              offset: Offset(0, 12),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 16,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            children: [
              // Watermark
              Positioned(
                bottom: -10,
                right: -10,
                child: Opacity(
                  opacity: 0.07,
                  child: Text(
                    "NEKOVERSE",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 80,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 4,
                    ),
                  ),
                ),
              ),
              // Decorative circles
              Positioned(
                top: -30,
                left: -30,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.07),
                  ),
                ),
              ),
              Positioned(
                bottom: 60,
                right: -15,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.05),
                  ),
                ),
              ),
              // Glossy shine
              Positioned(
                top: 0, left: 0, right: 0,
                height: 80,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(0.12),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              // Content
              Padding(
                padding: EdgeInsets.fromLTRB(22, 20, 22, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Icon + Badge
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.18),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: Center(
                            child: Icon(
                              menu['icon'],
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            color: (menu['badgeColor'] as Color).withOpacity(0.18),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: (menu['badgeColor'] as Color).withOpacity(0.55),
                              width: 1.5,
                            ),
                          ),
                          child: Text(
                            menu['badge'],
                            style: TextStyle(
                              color: menu['badgeColor'],
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 18),
                    // Title
                    Text(
                      menu['title'],
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.8,
                        shadows: [Shadow(color: Colors.black26, blurRadius: 4)],
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      menu['subtitle'],
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.75),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w400,
                        letterSpacing: 0.3,
                      ),
                    ),
                    SizedBox(height: 10),
                    // Divider
                    Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.3),
                            Colors.white.withOpacity(0.05),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    // Description
                    Text(
                      menu['description'],
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.82),
                        fontSize: 12.5,
                        height: 1.55,
                        letterSpacing: 0.2,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 12),
                    // Features chips
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: features.take(3).map((f) => Container(
                        padding: EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white.withOpacity(0.2)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.check_circle_outline, color: Colors.white.withOpacity(0.8), size: 11),
                            SizedBox(width: 4),
                            Text(
                              f,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.88),
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      )).toList(),
                    ),
                    Spacer(),
                    // START MODULE button
                    Container(
                      margin: EdgeInsets.only(bottom: 18),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => menu['page'],
                              ),
                            );
                          },
                          splashColor: Colors.white.withOpacity(0.15),
                          child: Padding(
                            padding: EdgeInsets.symmetric(vertical: 14),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "START MODULE",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Container(
                                  width: 22,
                                  height: 22,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 12),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// ─── CHAT INFO PANEL ──────────────────────────────────────────────────────
Widget _buildChatInfoPanel() {
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 20),
    padding: EdgeInsets.symmetric(horizontal: 18, vertical: 14),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.05),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: Colors.white.withOpacity(0.08), width: 1),
    ),
    child: Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: Color(0xFF25D366).withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: Icon(Icons.info_outline_rounded, color: Color(0xFF25D366), size: 16),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Semua menu telah diuji coba dan tanpa gimmick real work 100%",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.88),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                ),
              ),
              SizedBox(height: 4),
              Row(
                children: [
                  Container(
                    width: 5, height: 5,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF25D366),
                      boxShadow: [BoxShadow(color: Color(0xFF25D366).withOpacity(0.7), blurRadius: 5)],
                    ),
                  ),
                  SizedBox(width: 6),
                  Text(
                    "NEKOVERSE TEAM",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

// ─── Banner Video (ELEGAN & MODERN) ────────────────────────────────────────
Widget _buildBannerVideo() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 190,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [
              Color(0xFF0A0E1A),
              Color(0xFF1A1A2E),
              Color(0xFF16213E),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: kCyan.withOpacity(0.12),
              blurRadius: 30,
              spreadRadius: 3,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: kPurple.withOpacity(0.08),
              blurRadius: 20,
              spreadRadius: 1,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video Background
            if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _menuVideoCtrl!.value.size.width,
                  height: _menuVideoCtrl!.value.size.height,
                  child: VideoPlayer(_menuVideoCtrl!),
                ),
              )
            else
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF0A0E1A),
                      Color(0xFF1A1A2E),
                      Color(0xFF16213E),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            
            // Gradient Overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.65),
                    Colors.transparent,
                    Colors.black.withOpacity(0.4),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
            ),
            
            // Neon Border Effect
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: kCyan.withOpacity(0.15),
                  width: 1.5,
                ),
              ),
            ),

            // ─── Content ──────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // Badge NEKOVERSE LIVE
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          kCyan.withOpacity(0.2),
                          kPurple.withOpacity(0.15),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: kCyan.withOpacity(0.25),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: kCyan.withOpacity(0.1),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 800),
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: kCyan,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'NEKOVERSE LIVE',
                          style: TextStyle(
                            color: kCyan,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Colors.white, kCyan],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      'NEKOVERSE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 3,
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Platform Bug & Tools Terpercaya',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 11,
                      letterSpacing: 1,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),

            // ─── Dekorasi Cyber ─────────────────────────────
            Positioned(
              right: 16,
              top: 16,
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: kCyan.withOpacity(0.08),
                    width: 1,
                  ),
                  gradient: RadialGradient(
                    colors: [
                      kCyan.withOpacity(0.05),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: Icon(
                  Icons.code_rounded,
                  color: kCyan.withOpacity(0.2),
                  size: 24,
                ),
              ),
            ),

            // ─── Dekorasi Grid ──────────────────────────────
            Positioned(
              left: 0,
              bottom: 0,
              child: Container(
                width: 100,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kCyan.withOpacity(0.03),
                      Colors.transparent,
                    ],
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                  ),
                ),
                child: CustomPaint(
                  painter: _GridPatternPainter(
                    gridColor: kCyan.withOpacity(0.04),
                    lineColor: kCyan.withOpacity(0.02),
                    spacing: 12,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

// ─── THANKS TO BANNER ──────────────────────────────────────────────────────
Widget _buildThanksToBanner() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: GestureDetector(
      onTap: () {
        // Navigasi ke halaman Thanks To
        Navigator.push(
          context,
          _slideRoute(const ThanksToPage()),
        );
      },
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF8B0000), Color(0xFFB22222)], // Dark Red ke Firebrick
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF8B0000).withOpacity(0.4),
                blurRadius: 15,
              ),
            ],
          ),
          child: Stack(
            children: [
              // ─── Background Icon ──────────────────────────
              Positioned(
                right: -20,
                top: -30,
                child: Icon(
                  Icons.people_alt_rounded,
                  size: 120,
                  color: Colors.white.withOpacity(0.12),
                ),
              ),
              
              // ─── Konten ──────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 20,
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.people_alt_rounded,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            "Thanks To",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Orbitron",
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Our Team & Contributors",
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right,
                      color: Colors.white,
                      size: 28,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

  // ── Welcome Card (Lebar mengikuti dashboard, tapi konten fixed) ──────────────
Widget _buildWelcomeCard() {
  // Hitung status akun
  final now = DateTime.now();
  int accountDaysLeft = 0;
  double accountProgress = 0.0;
  String accountStatus = "ACTIVE";
  bool isAccountExpired = false;

  try {
    final expired = DateTime.parse(expiredDate);
    final difference = expired.difference(now);
    if (difference.inDays <= 0) {
      isAccountExpired = true;
      accountStatus = "EXPIRED";
      accountDaysLeft = 0;
      accountProgress = 0.0;
    } else {
      isAccountExpired = false;
      accountDaysLeft = difference.inDays;
      final totalDays = 30;
      accountProgress = (accountDaysLeft / totalDays).clamp(0.0, 1.0);
      if (accountDaysLeft <= 3) {
        accountStatus = "CRITICAL";
      } else if (accountDaysLeft <= 7) {
        accountStatus = "WARNING";
      } else {
        accountStatus = "ACTIVE";
      }
    }
  } catch (e) {
    accountStatus = "UNKNOWN";
    accountDaysLeft = 0;
    accountProgress = 0.0;
  }

  Color statusColor;
  IconData statusIcon;
  switch (accountStatus) {
    case "ACTIVE":
      statusColor = kGreen;
      statusIcon = Icons.check_circle_rounded;
      break;
    case "WARNING":
      statusColor = kOrange;
      statusIcon = Icons.warning_rounded;
      break;
    case "CRITICAL":
      statusColor = Colors.red;
      statusIcon = Icons.error_rounded;
      break;
    case "EXPIRED":
      statusColor = Colors.red.shade700;
      statusIcon = Icons.cancel_rounded;
      break;
    default:
      statusColor = kWhite54;
      statusIcon = Icons.help_rounded;
  }

  // Format expired date
  String formattedExpired = expiredDate;
  try {
    final date = DateTime.parse(expiredDate);
    formattedExpired = "${date.day}/${date.month}/${date.year}";
  } catch (_) {}

  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Container(
      width: double.infinity, // ← Lebar mengikuti dashboard
      padding: const EdgeInsets.all(16), // ← Fixed, tidak mengikuti DPI
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(16), // ← Fixed
        border: Border.all(color: statusColor.withOpacity(0.25), width: 1), // ← Fixed
        boxShadow: [
          BoxShadow(
            color: statusColor.withOpacity(0.06),
            blurRadius: 20,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──────────────────────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.dashboard_rounded, color: statusColor, size: 18), // ← Fixed
                  const SizedBox(width: 8), // ← Fixed
                  const Text(
                    "DASHBOARD",
                    style: TextStyle(
                      color: kWhite,
                      fontSize: 12, // ← Fixed
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), // ← Fixed
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14), // ← Fixed
                  border: Border.all(color: statusColor.withOpacity(0.35), width: 1), // ← Fixed
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(statusIcon, color: statusColor, size: 12), // ← Fixed
                    const SizedBox(width: 4), // ← Fixed
                    Text(
                      accountStatus,
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 9, // ← Fixed
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12), // ← Fixed

          // ── Progress Bar Masa Aktif ──────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Remaining Time",
                style: TextStyle(
                  color: kWhite54.withOpacity(0.8),
                  fontSize: 9, // ← Fixed
                  fontFamily: 'Orbitron',
                ),
              ),
              Text(
                "$accountDaysLeft Days Left",
                style: TextStyle(
                  color: statusColor,
                  fontSize: 9, // ← Fixed
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 4), // ← Fixed
          ClipRRect(
            borderRadius: BorderRadius.circular(4), // ← Fixed
            child: LinearProgressIndicator(
              value: accountProgress,
              minHeight: 4, // ← Fixed
              backgroundColor: kBg.withOpacity(0.5),
              valueColor: AlwaysStoppedAnimation<Color>(statusColor),
            ),
          ),
          const SizedBox(height: 14), // ← Fixed

          // ── Row 1: Role, Expired, Online ──────────────────────────────────
          Row(
            children: [
              _buildWelcomeStatChip(
                icon: _roleIcon(role),
                label: "ROLE",
                value: role.toUpperCase(),
                color: kOrange,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.calendar_month_rounded,
                label: "EXPIRED",
                value: formattedExpired,
                color: kCyan,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.people_alt_rounded,
                label: "ONLINE",
                value: "$onlineUsers Users",
                color: kGreen,
              ),
            ],
          ),
          const SizedBox(height: 6), // ← Fixed

          // ── Row 2: Device, Battery, Network ──────────────────────────────
          Row(
            children: [
              _buildWelcomeStatChip(
                icon: Icons.devices_rounded,
                label: "DEVICE",
                value: "Android ${androidId.substring(0, 4).toUpperCase()}",
                color: kPurple,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.battery_full_rounded,
                label: "BATTERY",
                value: "78% Charging",
                color: kGreen,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.wifi_rounded,
                label: "NETWORK",
                value: "WiFi 85%",
                color: kBlue,
              ),
            ],
          ),
          const SizedBox(height: 6), // ← Fixed

          // ── Row 3: RAM, Storage, System ──────────────────────────────────
          Row(
            children: [
              _buildWelcomeStatChip(
                icon: Icons.memory_rounded,
                label: "RAM",
                value: "2340MB / 4096MB",
                color: kPink,
                showProgress: true,
                progressValue: 0.57,
                progressColor: kPink,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.storage_rounded,
                label: "STORAGE",
                value: "86GB / 128GB",
                color: kCyan,
                showProgress: true,
                progressValue: 0.67,
                progressColor: kCyan,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.android_rounded,
                label: "SYSTEM",
                value: "API 33",
                color: kWhite54,
              ),
            ],
          ),
          const SizedBox(height: 6), // ← Fixed

          // ── Row 4: Session, Connections, Time ─────────────────────────────
          Row(
            children: [
              _buildWelcomeStatChip(
                icon: Icons.link_rounded,
                label: "SESSION",
                value: sessionKey.substring(0, 8).toUpperCase(),
                color: kPurple,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.network_check_rounded,
                label: "CONN",
                value: "$activeConns Active",
                color: kGreen,
              ),
              const SizedBox(width: 6), // ← Fixed
              _buildWelcomeStatChip(
                icon: Icons.timer_outlined,
                label: "TIME",
                value: _formatClock(DateTime.now()),
                color: kYellow,
              ),
            ],
          ),
          const SizedBox(height: 10), // ← Fixed

          // ── LIVE Badge ────────────────────────────────────────────────────
          Align(
            alignment: Alignment.centerLeft,
            child: ScaleTransition(
              scale: _pulseAnim,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), // ← Fixed
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20), // ← Fixed
                  border: Border.all(color: kGreen.withOpacity(0.5)), // ← Fixed
                  color: kGreen.withOpacity(0.08),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _AnimatedDot(color: kGreen, size: 6), // ← Fixed
                    const SizedBox(width: 6), // ← Fixed
                    const Text(
                      'LIVE',
                      style: TextStyle(
                        color: kGreen,
                        fontSize: 10, // ← Fixed
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

// ── SENDER WHATSAPP & INFO TOOLS ──────────────────────────────────────────
Widget _buildSenderAndToolsSection() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Row(
      children: [
        // ─── SENDER WHATSAPP ──────────────────────────────────────────────
        Expanded(
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                _slideRoute(BugSenderPage(
                  sessionKey: sessionKey,
                  username: username,
                  role: role,
                )),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF075E54).withOpacity(0.3),
                    const Color(0xFF25D366).withOpacity(0.15),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFF25D366).withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF25D366).withOpacity(0.25),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF075E54), Color(0xFF25D366)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          FontAwesomeIcons.whatsapp,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF25D366).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: const Color(0xFF25D366).withOpacity(0.4),
                          ),
                        ),
                        child: const Text(
                          "SENDER",
                          style: TextStyle(
                            color: Color(0xFF25D366),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Sender WhatsApp",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Kirim pesan & manage sender",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),

        // ─── INFO TOOLS ──────────────────────────────────────────────────
        Expanded(
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                _slideRoute(ToolsPage(
                  sessionKey: sessionKey,
                  userRole: role,
                  listDoos: listDoos,
                )),
              );
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF7C4DFF).withOpacity(0.3),
                    const Color(0xFF448AFF).withOpacity(0.15),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFF7C4DFF).withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF7C4DFF).withOpacity(0.25),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF7C4DFF), Color(0xFF448AFF)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.build_circle_outlined,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF7C4DFF).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: const Color(0xFF7C4DFF).withOpacity(0.4),
                          ),
                        ),
                        child: const Text(
                          "TOOLS",
                          style: TextStyle(
                            color: Color(0xFF7C4DFF),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Info Tools",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Akses tools & gateway",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

// ─── Welcome Stat Chip (Fixed Size) ──────────────────────────────────────────
Widget _buildWelcomeStatChip({
  required IconData icon,
  required String label,
  required String value,
  required Color color,
  bool showProgress = false,
  double progressValue = 0.0,
  Color? progressColor,
}) {
  return Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8), // ← Fixed
      decoration: BoxDecoration(
        color: kBg.withOpacity(0.4),
        borderRadius: BorderRadius.circular(8), // ← Fixed
        border: Border.all(color: color.withOpacity(0.15), width: 0.5), // ← Fixed
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 10), // ← Fixed
              const SizedBox(width: 4), // ← Fixed
              Text(
                label,
                style: TextStyle(
                  color: kWhite54.withOpacity(0.65),
                  fontSize: 6.5, // ← Fixed
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2), // ← Fixed
          Text(
            value,
            style: TextStyle(
              color: kWhite.withOpacity(0.9),
              fontSize: 8.5, // ← Fixed
              fontWeight: FontWeight.w600,
              fontFamily: 'Orbitron',
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
          if (showProgress) ...[
            const SizedBox(height: 3), // ← Fixed
            ClipRRect(
              borderRadius: BorderRadius.circular(2), // ← Fixed
              child: LinearProgressIndicator(
                value: progressValue.clamp(0.0, 1.0),
                minHeight: 2.5, // ← Fixed
                backgroundColor: kBg.withOpacity(0.6),
                valueColor: AlwaysStoppedAnimation<Color>(progressColor ?? color),
              ),
            ),
          ],
        ],
      ),
    ),
  );
}

// ─── Helper format clock ────────────────────────────────────────────────────
String _formatClock(DateTime dt) {
  return "${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}";
}

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.18),
              border: Border.all(color: color.withOpacity(0.6), width: 2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 14, spreadRadius: 2)],
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: kWhite, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron')),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 9), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: kBorder.withOpacity(0.5));

  // ── Quick Actions ─────────────────────────────────────────────────────────
Widget _buildQuickActionsSection() {
  final actions = [
    // ─── MANAGE SENDER ────────────────────────────────────
    _QuickActionData(
      icon: FontAwesomeIcons.whatsapp,
      bgIcon: FontAwesomeIcons.whatsapp,
      title: 'Manage Sender',
      subtitle: 'Manage your active sender',
      gradient: [const Color(0xFF00E676), const Color(0xFF00BFA5)],
      onTap: () => Navigator.push(
        context,
        _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
      ).then((_) {
        if (mounted && _newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      }),
    ),
    
    // ─── JOIN CHANNEL ──────────────────────────────────────
    _QuickActionData(
      icon: FontAwesomeIcons.telegram,
      bgIcon: FontAwesomeIcons.telegram,
      title: 'Join Channel',
      subtitle: 'NEKO Info Channel',
      gradient: [const Color(0xFF00E5FF), const Color(0xFF2979FF)],
      onTap: () => _openUrl('https://t.me/aboutszamz'),
    ),

    // ─── AL QURAN ──────────────────────────────────────────
    _QuickActionData(
      icon: FontAwesomeIcons.bookQuran,
      bgIcon: FontAwesomeIcons.bookQuran,
      title: 'Al Quran',
      subtitle: 'Baca Al-Quran',
      gradient: [const Color(0xFF7C4DFF), const Color(0xFFB388FF)],
      onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
    ),

    // ─── ANIME ─────────────────────────────────────────────
    _QuickActionData(
      icon: FontAwesomeIcons.tv,
      bgIcon: FontAwesomeIcons.tv,
      title: 'Anime',
      subtitle: 'Discover & Watch Anime',
      gradient: [const Color(0xFFFF6D00), const Color(0xFFFF9100)],
      onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
    ),
  ];

  return Column(
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Container(
              width: 44, height: 44,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [kYellow.withOpacity(0.2), Colors.transparent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: kYellow.withOpacity(0.3)),
              ),
              child: const Icon(Icons.bolt_rounded, color: kYellow, size: 22),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('QUICK ACTIONS',
                    style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15,
                      fontFamily: 'Orbitron', letterSpacing: 1)),
                Text('Fitur Cepat Akses',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [kYellow.withOpacity(0.15), Colors.transparent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: kYellow.withOpacity(0.4)),
              ),
              child: Row(children: [
                Container(
                    width: 7, height: 7,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: kYellow)),
                const SizedBox(width: 5),
                const Text('NEKOVERSE',
                    style: TextStyle(color: kYellow, fontSize: 11, fontWeight: FontWeight.bold)),
              ]),
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
      SizedBox(
        height: 180,
        child: PageView.builder(
          controller: _qaPageCtrl,
          itemCount: actions.length,
          onPageChanged: (index) {
            if (mounted) setState(() => _currentQaPage = index.toDouble());
          },
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: _buildAnimatedQuickActionCard(
                action: actions[index],
                index: index,
                currentPage: _currentQaPage,
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 12),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(actions.length, (index) {
          final bool isActive = _currentQaPage.round() == index;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: isActive ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              gradient: isActive 
                  ? const LinearGradient(
                      colors: [kYellow, Color(0xFFFF6D00)],
                    )
                  : LinearGradient(
                      colors: [Colors.white24, Colors.white12],
                    ),
            ),
          );
        }),
      ),
    ],
  );
}

// ─── ANIMATED QUICK ACTION CARD ──────────────────────────────────────────
Widget _buildAnimatedQuickActionCard({
  required _QuickActionData action,
  required int index,
  required double currentPage,
}) {
  bool _pressed = false;
  
  final double distance = (index - currentPage).abs();
  final double targetScale = distance <= 0.01 ? 1.0 : 0.85;
  final double targetOpacity = distance <= 0.01 ? 1.0 : 0.6;
  final Color borderColor = distance <= 0.01 
      ? Colors.white.withOpacity(0.3) 
      : Colors.transparent;
  final double shadowBlur = distance <= 0.01 ? 25 : 10;
  final double shadowSpread = distance <= 0.01 ? 4 : 1;

  return TweenAnimationBuilder<double>(
    tween: Tween<double>(begin: targetScale, end: targetScale),
    duration: const Duration(milliseconds: 350),
    curve: Curves.easeInOutCubic,
    builder: (context, scaleValue, child) {
      return TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: targetOpacity, end: targetOpacity),
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOutCubic,
        builder: (context, opacityValue, child) {
          return Transform.scale(
            scale: scaleValue,
            child: Opacity(
              opacity: opacityValue,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeInOutCubic,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: borderColor,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: action.gradient.first.withOpacity(
                        distance <= 0.01 ? 0.5 : 0.2
                      ),
                      blurRadius: shadowBlur,
                      spreadRadius: shadowSpread,
                      offset: const Offset(0, 8),
                    ),
                    if (distance <= 0.01)
                      BoxShadow(
                        color: Colors.white.withOpacity(0.1),
                        blurRadius: 30,
                        spreadRadius: 1,
                        offset: const Offset(0, 0),
                      ),
                  ],
                ),
                child: StatefulBuilder(
                  builder: (context, setState) {
                    return GestureDetector(
                      onTapDown: (_) => setState(() => _pressed = true),
                      onTapUp: (_) {
                        setState(() => _pressed = false);
                        action.onTap();
                      },
                      onTapCancel: () => setState(() => _pressed = false),
                      child: AnimatedScale(
                        scale: _pressed ? 0.92 : 1.0,
                        duration: const Duration(milliseconds: 150),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            gradient: LinearGradient(
                              colors: action.gradient,
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                right: -12,
                                bottom: -12,
                                child: AnimatedOpacity(
                                  duration: const Duration(milliseconds: 350),
                                  opacity: distance <= 0.01 ? 0.12 : 0.06,
                                  child: Icon(
                                    action.bgIcon,
                                    color: Colors.white,
                                    size: 110,
                                  ),
                                ),
                              ),
                              if (distance <= 0.01)
                                Positioned(
                                  top: -20,
                                  right: -20,
                                  child: Container(
                                    width: 80,
                                    height: 80,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: RadialGradient(
                                        colors: [
                                          action.gradient.first.withOpacity(0.3),
                                          Colors.transparent,
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              Padding(
                                padding: const EdgeInsets.all(22),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    AnimatedContainer(
                                      duration: const Duration(milliseconds: 350),
                                      width: distance <= 0.01 ? 56 : 50,
                                      height: distance <= 0.01 ? 56 : 50,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.white.withOpacity(
                                          distance <= 0.01 ? 0.28 : 0.22
                                        ),
                                        border: Border.all(
                                          color: Colors.white.withOpacity(
                                            distance <= 0.01 ? 0.4 : 0.1
                                          ),
                                          width: distance <= 0.01 ? 2 : 1,
                                        ),
                                      ),
                                      child: Icon(
                                        action.icon,
                                        color: Colors.white,
                                        size: distance <= 0.01 ? 28 : 24,
                                      ),
                                    ),
                                    const Spacer(),
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 350),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 14,
                                          vertical: 6,
                                        ),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(20),
                                          color: Colors.white.withOpacity(
                                            distance <= 0.01 ? 0.28 : 0.22
                                          ),
                                          border: Border.all(
                                            color: Colors.white.withOpacity(
                                              distance <= 0.01 ? 0.3 : 0.1
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          distance <= 0.01 ? 'ACTIVE →' : 'Tap →',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: distance <= 0.01 ? 12 : 11,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: distance <= 0.01 ? 1 : 0,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 350),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: distance <= 0.01 ? 19 : 17,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: distance <= 0.01 ? 1 : 0,
                                      ),
                                      child: Text(action.title),
                                    ),
                                    const SizedBox(height: 4),
                                    AnimatedDefaultTextStyle(
                                      duration: const Duration(milliseconds: 350),
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(
                                          distance <= 0.01 ? 0.9 : 0.7
                                        ),
                                        fontSize: distance <= 0.01 ? 13 : 12,
                                      ),
                                      child: Text(action.subtitle),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          );
        },
      );
    },
  );
}

  Widget _buildQuickActionCard(_QuickActionData action) {
  bool _pressed = false;
  return StatefulBuilder(
    builder: (context, setState) {
      return GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          action.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.92 : 1.0,
          duration: const Duration(milliseconds: 150),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: LinearGradient(
                  colors: action.gradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
              boxShadow: [
                BoxShadow(
                    color: action.gradient.first.withOpacity(0.4),
                    blurRadius: 20, offset: const Offset(0, 8))
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  right: -12, bottom: -12,
                  child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.08), size: 110),
                ),
                Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 50, height: 50,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle, color: Colors.white.withOpacity(0.22)),
                        child: Icon(action.icon, color: kWhite, size: 24),
                      ),
                      const Spacer(),
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white.withOpacity(0.22)),
                          child: const Text('Tap →',
                              style: TextStyle(color: kWhite, fontSize: 11, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(action.title,
                          style: const TextStyle(
                            color: kWhite, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
                      const SizedBox(height: 4),
                      Text(action.subtitle,
                          style: TextStyle(color: kWhite.withOpacity(0.8), fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  );
}

  // ─── Latest Updates (MODERN) ──────────────────────────────────────────────────
Widget _buildLatestUpdates() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [kOrange, Color(0xFFFF6D00)],
                ),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: kOrange.withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(
                Icons.dashboard_customize_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'LATEST UPDATES',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                Text(
                  'Update terbaru dari NEKOVERSE',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
            const Spacer(),
            if (newsList.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kOrange.withOpacity(0.15),
                      Colors.transparent,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: kOrange.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 800),
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: kOrange,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      '${newsList.length} New',
                      style: const TextStyle(
                        color: kOrange,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
      const SizedBox(height: 12),
      if (newsList.isNotEmpty)
        SizedBox(
          height: 220,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: newsList.length,
            itemBuilder: (ctx, i) => _buildNewsCardModern(newsList[i]),
          ),
        ),
      if (newsList.isEmpty)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Container(
            height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: kCard,
              border: Border.all(color: kBorder.withOpacity(0.3)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.inbox_rounded,
                  color: Colors.white.withOpacity(0.08),
                  size: 32,
                ),
                const SizedBox(height: 6),
                Text(
                  'Tidak ada update',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.3),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
    ],
  );
}

// ─── News Card Modern ──────────────────────────────────────────────────────────
Widget _buildNewsCardModern(dynamic item) {
  final imgUrl = item['image']?.toString() ?? '';
  final title = item['title']?.toString() ?? 'No Title';
  final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
  final description = item['description']?.toString() ?? '';
  final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

  return Container(
    width: cardWidth,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      color: kCard,
      border: Border.all(
        color: kBorder.withOpacity(0.3),
        width: 1.5,
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.35),
          blurRadius: 20,
          offset: const Offset(0, 8),
        ),
        BoxShadow(
          color: kCyan.withOpacity(0.03),
          blurRadius: 30,
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ─── Image ────────────────────────────────────────
        ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
          child: Stack(
            children: [
              Container(
                height: 110,
                width: double.infinity,
                color: kCardAlt,
                child: imgUrl.isNotEmpty
                    ? Image.network(
                        imgUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: kCardAlt,
                          child: Center(
                            child: Icon(
                              Icons.image_not_supported,
                              color: Colors.white.withOpacity(0.15),
                              size: 32,
                            ),
                          ),
                        ),
                      )
                    : Container(
                        color: kCardAlt,
                        child: Center(
                          child: Icon(
                            Icons.article_rounded,
                            color: Colors.white.withOpacity(0.12),
                            size: 32,
                          ),
                        ),
                      ),
              ),
              // Gradient Overlay
              Container(
                height: 110,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.25),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
              // Badge NEW dengan Animasi
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF6D00), Color(0xFFFF9100)],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6D00).withOpacity(0.3),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: const Text(
                    'NEW',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        // ─── Content ──────────────────────────────────────
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  height: 1.3,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              if (description.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 10,
                    height: 1.3,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
              const Spacer(),
              const SizedBox(height: 6),
              Row(
                children: [
                  Icon(
                    Icons.access_time_rounded,
                    color: Colors.white.withOpacity(0.25),
                    size: 10,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    date.isNotEmpty
                        ? (date.length > 10 ? date.substring(0, 10) : date)
                        : 'Baru saja',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.25),
                      fontSize: 9,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: kCyan.withOpacity(0.08),
                    ),
                    child: Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: kCyan.withOpacity(0.4),
                      size: 9,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

  // ─── Prayer Section (PREMIUM) ──────────────────────────────────────────────────
Widget _buildPrayerSection() {
  final prayerColors = [
    const Color(0xFF6C5CE7),
    const Color(0xFFFDCB6E),
    const Color(0xFFE17055),
    const Color(0xFF00CEC9),
    const Color(0xFF0984E3),
  ];
  final prayerIcons = [
    Icons.nights_stay_rounded,
    Icons.wb_sunny_rounded,
    Icons.cloud_rounded,
    Icons.wb_twilight_rounded,
    Icons.nightlight_round,
  ];
  final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kCard,
            kCard.withOpacity(0.85),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: kBorder.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: kGreen.withOpacity(0.04),
            blurRadius: 30,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── Header ──────────────────────────────────────
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kGreen.withOpacity(0.2),
                      kGreen.withOpacity(0.08),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: kGreen.withOpacity(0.25),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.mosque, color: kGreen, size: 22),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'JADWAL SHOLAT',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_rounded,
                          color: kGreen.withOpacity(0.5),
                          size: 10,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _prayerCity,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // ─── Actions ──────────────────────────────────
              GestureDetector(
                onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                child: Container(
                  width: 36,
                  height: 36,
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _locationGranted
                        ? kGreen.withOpacity(0.12)
                        : Colors.white.withOpacity(0.04),
                    border: Border.all(
                      color: _locationGranted
                          ? kGreen.withOpacity(0.4)
                          : Colors.white.withOpacity(0.08),
                      width: 1.5,
                    ),
                  ),
                  child: _locationLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            color: kGreen,
                            strokeWidth: 2,
                          ),
                        )
                      : Icon(
                          _locationGranted
                              ? Icons.my_location_rounded
                              : Icons.location_searching_rounded,
                          color: _locationGranted ? kGreen : Colors.white54,
                          size: 16,
                        ),
                ),
              ),
              GestureDetector(
                onTap: _showChangeCityDialog,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [kGreen, Color(0xFF00C853)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: kGreen.withOpacity(0.25),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.edit_location_alt_rounded,
                        color: Colors.white,
                        size: 12,
                      ),
                      SizedBox(width: 4),
                      Text(
                        'GANTI',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // ─── Next Prayer ─────────────────────────────────
          if (_nextPrayerLabel.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    kGreen.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: kGreen.withOpacity(0.15),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kGreen,
                        boxShadow: [
                          BoxShadow(
                            color: kGreen.withOpacity(0.4),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [kGreen.withOpacity(0.2), kGreen.withOpacity(0.05)],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: kGreen.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: const Text(
                      'NOW',
                      style: TextStyle(
                        color: kGreen,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 14),

          // ─── Prayer Time Cards ───────────────────────────
          if (_prayerLoading)
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: CircularProgressIndicator(
                  color: kGreen,
                  strokeWidth: 2,
                ),
              ),
            )
          else
            SizedBox(
              height: 110,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: prayerKeys.length,
                itemBuilder: (ctx, i) {
                  final key = prayerKeys[i];
                  final time = _prayerTimes[key] ?? '--:--';
                  final color = prayerColors[i];
                  final icon = prayerIcons[i];
                  final isNext = key == _nextPrayerLabel;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.easeOut,
                    margin: EdgeInsets.only(
                      right: 8,
                      bottom: isNext ? 0 : 6,
                      top: isNext ? 0 : 6,
                    ),
                    width: 90,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isNext
                            ? [color, color.withOpacity(0.8)]
                            : [color.withOpacity(0.6), color.withOpacity(0.3)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(isNext ? 0.4 : 0.15),
                          blurRadius: isNext ? 16 : 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                      border: isNext
                          ? Border.all(
                              color: Colors.white.withOpacity(0.2),
                              width: 1.5,
                            )
                          : null,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icon, color: Colors.white, size: 20),
                          const SizedBox(height: 4),
                          Text(
                            key.toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            time,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    ),
  );
}

  // ─── Hadith Section (PREMIUM) ──────────────────────────────────────────────────
Widget _buildHadithSection() {
  if (_hadithLoading) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              kCard,
              kCard.withOpacity(0.85),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: kBorder.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                color: kCyan,
                strokeWidth: 2,
              ),
              SizedBox(height: 12),
              Text(
                'Memuat Hadith...',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final arabic = _hadith?['data']?['text']?['ar'] ??
      'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
  final indo = _hadith?['data']?['text']?['id'] ??
      'Sesungguhnya setiap amalan tergantung pada niatnya.';
  final number = _hadith?['data']?['id']?.toString() ?? '1';
  final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
  final grade = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            kCard,
            kCard.withOpacity(0.85),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: kBorder.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: kCyan.withOpacity(0.04),
            blurRadius: 30,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── Header ──────────────────────────────────────
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kCyan.withOpacity(0.2),
                      kCyan.withOpacity(0.08),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: kCyan.withOpacity(0.25),
                    width: 1.5,
                  ),
                ),
                child: const Center(
                  child: Icon(
                    Icons.menu_book_rounded,
                    color: kCyan,
                    size: 22,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'HADITH OF THE DAY',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                    Row(
                      children: [
                        Container(
                          width: 4,
                          height: 4,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: kCyan,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          grade,
                          style: TextStyle(
                            color: kCyan.withOpacity(0.6),
                            fontSize: 10,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          width: 4,
                          height: 4,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white24,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Tap card to read full',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.3),
                            fontSize: 9,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // ─── Refresh Button ────────────────────────────
              GestureDetector(
                onTap: _fetchRandomHadith,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        kCyan.withOpacity(0.12),
                        kCyan.withOpacity(0.04),
                      ],
                    ),
                    border: Border.all(
                      color: kCyan.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: Icon(
                    Icons.refresh_rounded,
                    color: kCyan.withOpacity(0.6),
                    size: 18,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // ─── Content ─────────────────────────────────────
          GestureDetector(
            onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF1A1F2E),
                        const Color(0xFF141824),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: kBorder.withOpacity(0.15),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    arabic,
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      height: 2.2,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF141824),
                        const Color(0xFF0D1117),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: kBorder.withOpacity(0.08),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          indo,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                            height: 1.7,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(6),
                        margin: const EdgeInsets.only(left: 8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kCyan.withOpacity(0.08),
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios_rounded,
                          color: kCyan.withOpacity(0.3),
                          size: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // ─── Footer ──────────────────────────────────────
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      kCyan.withOpacity(0.12),
                      kCyan.withOpacity(0.04),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: kCyan.withOpacity(0.15),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.receipt_long_rounded,
                      color: kCyan.withOpacity(0.5),
                      size: 12,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '${source.isNotEmpty ? source : "Muslim"} #$number',
                      style: TextStyle(
                        color: kCyan.withOpacity(0.6),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchRandomHadith,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.08),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.touch_app_rounded,
                        color: Colors.white.withOpacity(0.3),
                        size: 12,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Tap ganti',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (_showIntro) {
      return WelcomeNoMercyIntro(
        onFinished: () => setState(() => _showIntro = false),
      );
    }

    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          _buildBackgroundGrid(),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0D1117), Color(0xFF0A0D14)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBackgroundGrid() {
    return CustomPaint(
      size: Size.infinite,
      painter: _GridPatternPainter(
        gridColor: kCyan.withOpacity(0.04),
        lineColor: kPink.withOpacity(0.02),
        spacing: 35,
      ),
    );
  }

// ── AppBar ────────────────────────────────────────────────────────────────
PreferredSizeWidget _buildAppBar() {
  return AppBar(
    backgroundColor: kBg.withOpacity(0.95),
    elevation: 0,
    iconTheme: const IconThemeData(color: kWhite),
    titleSpacing: 0,
    flexibleSpace: Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.4))),
      ),
    ),
    title: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        const SizedBox(width: 8),
        Text(
          'NEKOVERSE',
          style: TextStyle(
            color: kWhite,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
          ),
        ),
      ],
    ),
    centerTitle: false,
    actions: [
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          _slideRoute(ProfilePage(
            username: username, password: password,
            role: role, expiredDate: expiredDate, sessionKey: sessionKey,
          )),
        ),
        child: Container(
          width: 38, height: 38,
          margin: const EdgeInsets.only(right: 8),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: kRed.withOpacity(0.5), width: 2),
            color: kRed.withOpacity(0.2),
          ),
          child: ClipOval(
            child: _profileImage != null
                ? Image.file(_profileImage!, fit: BoxFit.cover)
                : const Icon(FontAwesomeIcons.userAstronaut, color: kRed, size: 20),
          ),
        ),
      ),
      const SizedBox(width: 4),
      GestureDetector(
        onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
        ),
      ),
      const SizedBox(width: 4),
    ],
  );
}

// ── Bottom Nav ────────────────────────────────────────────────────────────
Widget _buildBottomNav() {
  final items = [
    _NavItem(icon: Icons.dashboard_rounded, label: 'Dashboard'),
    _NavItem(icon: Icons.chat_rounded, label: 'Chat'),
    _NavItem(icon: Icons.people_rounded, label: 'Group'),
    _NavItem(icon: Icons.info_outline_rounded, label: 'Info'),
    _NavItem(icon: Icons.build_circle_outlined, label: 'Tools'),
  ];

  const Color accentPink = Color(0xFFFF4FA3);
  const Color accentRed = Color(0xFFFF5252);
  const Color primaryPink = Color(0xFFE91E63);
  const Color primaryRed = Color(0xFFE53935);

  return Container(
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
    decoration: BoxDecoration(
      color: const Color(0xFF0B101B),
      borderRadius: BorderRadius.circular(30),
      border: Border.all(
        color: const Color(0xFF1E2638),
        width: 1.5,
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.5),
          blurRadius: 20,
          offset: const Offset(0, 10),
        ),
      ],
    ),
    child: SizedBox(
      height: 75,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (i) {
          final isActive = _navIndex == i;

          // ── HAPUS Expanded ──
          return GestureDetector(
            onTap: () => _onNavTap(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeInOut,
              padding: EdgeInsets.symmetric(
                horizontal: isActive ? 18 : 12,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: isActive ? (i==0 ? primaryPink.withOpacity(0.2) : primaryRed.withOpacity(0.2))  // ← BACKGROUND MERAH TRANSPARAN
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(16),
                border: isActive
                    ? Border.all(
                        color: (i==0 ? accentPink : accentRed).withOpacity(0.6),  // ← BORDER MERAH
                        width: 1.5,
                      )
                    : null,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,  // ← LEBAR MENGIKUTI TEKS
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    items[i].icon,
                    color: isActive ? (i==0 ? accentPink : accentRed) : const Color(0xFF49586E),
                    size: 26,
                  ),
                  if (isActive) ...[
                    const SizedBox(width: 8),
                    Text(
                      items[i].label,
                      style: TextStyle(
                        color: i==0 ? accentPink : accentRed,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        }),
      ),
    ),
  );
}

  // ── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kCyan.withOpacity(0.6), width: 2.5),
                            boxShadow: [BoxShadow(color: kCyan.withOpacity(0.3), blurRadius: 14, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(FontAwesomeIcons.userAstronaut, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kCyan, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.3) : kBorder.withOpacity(0.4)),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : kCyan, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  final bool isCenter;
  const _NavItem({
    required this.icon,
    required this.label,
    this.isCenter = false,
  });
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  
  @override  // ✅ INI YANG DIGANTI (sebelumnya @init)
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}
