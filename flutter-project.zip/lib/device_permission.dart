import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

const String deviceApiBase = 'http://omhcserver.mbudhost.biz.id:13083';

class DevicePermissionStore {
  static Future<PermissionResult> getFor(String username, String sessionKey) async {
    if (username.toLowerCase() == 'owner') {
      return PermissionResult(approved: true, allDevices: true, devices: const []);
    }

    try {
      final response = await http.get(
        Uri.parse('$deviceApiBase/devicePerms?key=$sessionKey&username=${Uri.encodeComponent(username)}'),
      ).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          return PermissionResult(
            approved: data['approved'] == true,
            allDevices: data['allDevices'] == true,
            devices: List<String>.from(data['devices'] ?? const []),
          );
        }
      }
    } catch (error) {
      debugPrint('[DevicePerm] getFor error: $error');
    }

    return PermissionResult(approved: false, allDevices: false, devices: const []);
  }

  static Future<bool> setPerm(
    String ownerKey,
    String username, {
    required bool approved,
    required bool allDevices,
    required List<String> devices,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$deviceApiBase/setDevicePerm?key=$ownerKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'approved': approved,
          'allDevices': allDevices,
          'devices': devices,
        }),
      ).timeout(const Duration(seconds: 8));
      final data = jsonDecode(response.body);
      return data['valid'] == true;
    } catch (error) {
      debugPrint('[DevicePerm] setPerm error: $error');
      return false;
    }
  }

  static Future<bool> removePerm(String ownerKey, String username) async {
    return setPerm(ownerKey, username,
        approved: false, allDevices: false, devices: const []);
  }

  static Future<Map<String, dynamic>> getAll(String ownerKey) async {
    try {
      final response = await http.get(
        Uri.parse('$deviceApiBase/listDevicePerms?key=$ownerKey'),
      ).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          return Map<String, dynamic>.from(data['perms'] ?? const {});
        }
      }
    } catch (error) {
      debugPrint('[DevicePerm] getAll error: $error');
    }
    return const {};
  }
}

class PermissionResult {
  final bool approved;
  final bool allDevices;
  final List<String> devices;

  const PermissionResult({
    required this.approved,
    required this.allDevices,
    required this.devices,
  });

  bool canSee(String? deviceId) {
    if (!approved) return false;
    if (allDevices) return true;
    return deviceId != null && devices.contains(deviceId);
  }
}
