import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';

// ── COLOR SCHEME (Updated for Space/Neon Theme) ─────────────────────
class _AC {
  static const bg       = Color(0xFF050510);
  static const bg2      = Color(0xFF0A0B1A);
  static const surface  = Color(0xFF101426); // Deep blue space
  static const card     = Color(0xFF101426); // For glassmorphism base
  static const accent   = Color(0xFF00E5FF); // Neon Cyan
  static const accent2  = Color(0xFF9D00FF); // Electric Purple
  static const accent3  = Color(0xFFFF007F); // Hot Magenta
  static const gold     = Color(0xFFC4B5FD);
  static const success  = Color(0xFF25D366);
  static const text     = Color(0xFFFFFFFF);
  static const muted    = Color(0xB3FFFFFF);
  static const muted2   = Color(0x66FFFFFF);
  static const border   = Color(0x26FFFFFF); // White with opacity
  static const border2  = Color(0x1AFFFFFF);
  static const glassBg  = Color(0x66101426); // Glass base
  static const glassBorder = Color(0x33FFFFFF);
}

// ── ATTACK PAGE ──────────────────────────────────────────────────────
class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  // ── Video Background ──
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  final targetController = TextEditingController();
  static const String baseUrl = "http://omhcserver.mbudhost.biz.id:13083";

  // ── Animation Controllers ─────────────────────────────────────────
  late AnimationController _pulseController;
  late AnimationController _staggerController;
  late AnimationController _btnPress;

  // ── State ─────────────────────────────────────────────────────────
  String selectedBugId = "";
  bool _isSending = false;
  String _senderType = "private";
  int _globalSenderCount = 0;
  int _privateSenderCount = 0;
  bool _isLoadingSenders = false;
  int _activeStep = 0;
  bool _isTargetFocused = false;
  bool _hasNoSender = false;

  bool get canUseGlobalSender {
    const allowed = ["founder", "vip", "owner", "high admin", "moderator", "high owner", "dev"];
    return allowed.contains(widget.role.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _staggerController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _btnPress = AnimationController(vsync: this, duration: const Duration(milliseconds: 100), lowerBound: 0.0, upperBound: 1.0);

    if (widget.listBug.isNotEmpty) selectedBugId = widget.listBug[0]['bug_id'];
    if (!canUseGlobalSender) _senderType = "private";
    _fetchSenderCounts();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _staggerController.dispose();
    _btnPress.dispose();
    targetController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  // ── Stagger Animation Helper ──────────────────────────────────────
  Animation<double> _anim(int i) {
    final s = (i * 0.07).clamp(0.0, 0.55);
    final e = (s + 0.38).clamp(0.0, 1.0);
    return CurvedAnimation(
      parent: _staggerController,
      curve: Interval(s, e, curve: Curves.easeOut),
    );
  }

  // ── API ───────────────────────────────────────────────────────────
  Future<void> _fetchSenderCounts() async {
    if (!mounted) return;
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['connections'] != null) {
          final priv = (data['connections']['private'] as List?) ?? [];
          final glob = (data['connections']['global'] as List?) ?? [];
          final onlinePriv = priv.where((s) => s['isActive'] == true).length;
          final onlineGlob = glob.where((s) => s['isActive'] == true).length;
          if (mounted) {
            setState(() {
              _privateSenderCount = onlinePriv;
              _globalSenderCount = onlineGlob;
              _hasNoSender = (onlinePriv == 0 && onlineGlob == 0);
            });
          }
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  String? formatPhoneNumber(String input) {
    final c = input.replaceAll(RegExp(r'[^\d]'), '');
    if (c.startsWith('0') || c.length < 8) return null;
    return c;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;
    _btnPress.forward().then((_) => _btnPress.reverse());
    setState(() { _isSending = true; _activeStep = 1; });

    final raw = targetController.text.trim();
    final target = formatPhoneNumber(raw);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number", "Use international format (e.g., +62, 1, 44), not 08xxx.");
      setState(() { _isSending = false; _activeStep = 0; });
      return;
    }

    try {
      final res = await http.get(
        Uri.parse(
          "$baseUrl/api/whatsapp/sendBug?key=${Uri.encodeComponent(key)}&target=${Uri.encodeComponent(target)}&bug=${Uri.encodeComponent(selectedBugId)}&senderType=$_senderType",
        ),
      ).timeout(const Duration(seconds: 35));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Cooldown ${data["wait"] ?? ""} detik. Tunggu sebentar.");
      } else if (data["valid"] == false) {
        _showAlert("Gagal", data["message"] ?? "Akses ditolak atau session key tidak valid.");
      } else if (data["sended"] == false) {
        _showAlert("Gagal", data["message"] ?? "Tidak ada sender yang aktif. Tambahkan sender dulu.");
      } else if (data["sended"] == true) {
        setState(() => _activeStep = 2);
        _showSuccessPopup(target);
      } else {
        _showAlert("Gagal", "Respons tidak dikenali dari server.");
      }
    } catch (_) {
      _showAlert("Error", "Connection error. Please try again.");
    } finally {
      if (mounted) {
        setState(() { _isSending = false; if (_activeStep != 2) _activeStep = 0; });
      }
    }
  }

  // ── Alert (Bottom Sheet — Glass style) ─────────────────────────────
  void _showAlert(String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 16),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: _AC.glassBg,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _AC.glassBorder, width: 1.2),
                boxShadow: [
                  BoxShadow(color: _AC.accent2.withOpacity(0.2), blurRadius: 20, spreadRadius: 2),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 40, height: 4,
                      decoration: BoxDecoration(
                        color: _AC.muted2,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: _AC.accent3.withOpacity(0.15),
                            border: Border.all(color: _AC.accent3.withOpacity(0.3)),
                            boxShadow: [BoxShadow(color: _AC.accent3.withOpacity(0.2), blurRadius: 10)],
                          ),
                          child: Center(child: _DynamicIcon(FontAwesomeIcons.triangleExclamation, color: _AC.accent3, size: 17)),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 2),
                              Text(title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w700, color: _AC.text)),
                              const SizedBox(height: 4),
                              Container(width: 30, height: 2, decoration: BoxDecoration(color: _AC.accent3.withOpacity(0.5), borderRadius: BorderRadius.circular(1))),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _AC.border2),
                      ),
                      child: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _AC.muted, height: 1.6)),
                    ),
                    const SizedBox(height: 20),
                    Align(
                      alignment: Alignment.centerRight,
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                          decoration: BoxDecoration(
                            color: _AC.accent2,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [BoxShadow(color: _AC.accent2.withOpacity(0.4), blurRadius: 15, spreadRadius: 1)],
                          ),
                          child: const Text('OK', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 2)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _SuccessDialog(
        target: target,
        senderType: _senderType,
        onDismiss: () { Navigator.of(context).pop(); setState(() => _activeStep = 0); },
      ),
    );
  }

  Future<void> _pasteTarget() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) targetController.text = data!.text!.replaceAll(RegExp(r'[^\d]'), '');
  }

  // ── Video Background ──────────────────────────────
  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.networkUrl(Uri.parse('https://files.catbox.moe/msg0qb.mp4'))
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _AC.bg,
      body: Stack(
        children: [
          // ── Video Background ──
          if (_bgVideoReady && _bgVideoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _bgVideoController.value.size.width,
                  height: _bgVideoController.value.size.height,
                  child: VideoPlayer(_bgVideoController),
                ),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.5,
                  colors: [Color(0xFF0F142B), Color(0xFF050510)],
                ),
              ),
            ),
          // ── Dark overlay with slight blue/space tint ──
          Container(color: Colors.black.withOpacity(0.5)),
          
          // ── Page content ──
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Column(
                        children: [
                          const SizedBox(height: 16),
                          _buildHeroBanner(),
                          const SizedBox(height: 16),
                          _buildProfileCard(),
                          const SizedBox(height: 16),
                          if (_hasNoSender) _buildNoSenderWarning(),
                          if (_hasNoSender) const SizedBox(height: 12),
                          _buildTargetCard(),
                          const SizedBox(height: 16),
                          _buildBugArsenalCard(),
                          const SizedBox(height: 16),
                          _buildDeployCard(),
                          const SizedBox(height: 24),
                          _buildLaunchButton(),
                          const SizedBox(height: 16),
                          _buildStatusBar(),
                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HEADER — Glass Dashboard style
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Row(
        children: [
          // Back button
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: _AC.surface.withOpacity(0.6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _AC.glassBorder),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10)],
              ),
              child: const Icon(Icons.arrow_back_ios_new, color: _AC.text, size: 18),
            ),
          ),
          const SizedBox(width: 16),
          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "CONTACT BUG",
                  style: TextStyle(
                    color: _AC.text,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: "MADEEvolveSansEVO",
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8, height: 8,
                      decoration: BoxDecoration(
                        color: _AC.accent,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: _AC.accent, blurRadius: 8, spreadRadius: 1)],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _isSending ? "INJECTING..." : "READY",
                      style: const TextStyle(
                        color: _AC.muted,
                        fontSize: 11,
                        fontFamily: "ShareTechMono",
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Right actions
          Row(
            children: [
              // Bell
              Container(
                width: 42, height: 42,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  color: _AC.surface.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _AC.glassBorder),
                ),
                child: const Center(child: _DynamicIcon(FontAwesomeIcons.bell, color: _AC.muted, size: 16)),
              ),
              // Lock/Count
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _AC.surface.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _AC.glassBorder),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const _DynamicIcon(FontAwesomeIcons.lock, color: _AC.accent, size: 14),
                    const SizedBox(width: 8),
                    Text(
                      "${_privateSenderCount + _globalSenderCount}",
                      style: const TextStyle(
                        color: _AC.text,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  GLASS CARD HELPER
  // ═══════════════════════════════════════════════════════════════════
  Widget _glassCard({required Widget child, int idx = -1, double? padding}) {
    Widget cardChild = ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.all(padding ?? 20),
          decoration: BoxDecoration(
            color: _AC.glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _AC.glassBorder, width: 1.2),
          ),
          child: child,
        ),
      ),
    );

    if (idx >= 0) {
      final a = _anim(idx);
      return FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween(begin: const Offset(0, 0.05), end: Offset.zero).animate(a),
          child: cardChild,
        ),
      );
    }
    return cardChild;
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HERO BANNER — Timeline Stepper with Custom Paint Arc
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildHeroBanner() {
    return _glassCard(
      idx: 0,
      padding: 20,
      child: Column(
        children: [
          SizedBox(
            height: 100,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Arc Line
                Positioned(
                  top: 30,
                  left: 20,
                  right: 20,
                  child: CustomPaint(
                    size: const Size(double.infinity, 40),
                    painter: _ArcPainter(),
                  ),
                ),
                // Step Nodes
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildHeroStep(0, FontAwesomeIcons.keyboard, 'INPUT'),
                    _buildHeroStep(1, FontAwesomeIcons.droplet, 'INJECT'),
                    _buildHeroStep(2, FontAwesomeIcons.circleCheck, 'DONE'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroStep(int step, dynamic icon, String title) {
    final isActive = _activeStep == step;
    final isDone = _activeStep > step;
    final color = isDone ? _AC.success : isActive ? _AC.accent : _AC.muted2;

    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (ctx, _) {
            final p = _pulseController.value;
            return Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isActive ? _AC.surface.withOpacity(0.8) : Colors.transparent,
                border: Border.all(
                  color: isActive 
                      ? _AC.accent.withOpacity(0.8 + p * 0.2) 
                      : isDone 
                          ? _AC.success.withOpacity(0.5) 
                          : _AC.muted2.withOpacity(0.3),
                  width: isActive ? 2.5 : 1.5,
                ),
                boxShadow: isActive
                    ? [BoxShadow(color: _AC.accent.withOpacity(0.3 + p * 0.2), blurRadius: 20, spreadRadius: 2)]
                    : isDone
                        ? [BoxShadow(color: _AC.success.withOpacity(0.2), blurRadius: 10)]
                        : null,
              ),
              child: Center(
                child: isDone 
                    ? Icon(Icons.check, color: _AC.success, size: 24) 
                    : _DynamicIcon(icon, color: color, size: 22),
              ),
            );
          },
        ),
        const SizedBox(height: 10),
        Text(
          title, 
          style: TextStyle(
            fontFamily: 'MADEEvolveSansEVO', 
            fontSize: 11, 
            fontWeight: FontWeight.w700, 
            letterSpacing: 1.5, 
            color: color,
            shadows: isActive ? [Shadow(color: _AC.accent.withOpacity(0.5), blurRadius: 8)] : null,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  NO SENDER WARNING
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNoSenderWarning() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, _) {
        final p = _pulseController.value;
        return ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: Colors.red.withOpacity(0.15),
                border: Border.all(color: Colors.redAccent.withOpacity(0.5), width: 1.5),
                boxShadow: [BoxShadow(color: Colors.redAccent.withOpacity(0.1 + p * 0.1), blurRadius: 15, spreadRadius: 1)],
              ),
              child: Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: Colors.redAccent.withOpacity(0.2),
                      border: Border.all(color: Colors.redAccent.withOpacity(0.4)),
                    ),
                    child: const Center(child: _DynamicIcon(FontAwesomeIcons.triangleExclamation, color: Colors.redAccent, size: 18)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('NO SENDER DETECTED', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, color: Colors.redAccent, letterSpacing: 1.5)),
                        const SizedBox(height: 4),
                        const Text('Add a sender first from the Sender Manager before attacking.', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _AC.muted, height: 1.4)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: _isLoadingSenders ? null : _fetchSenderCounts,
                    child: Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.redAccent.withOpacity(0.1),
                        border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
                      ),
                      child: Center(
                        child: _isLoadingSenders
                            ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.redAccent))
                            : const _DynamicIcon(FontAwesomeIcons.rotate, color: Colors.redAccent, size: 14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PROFILE CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildProfileCard() {
    return _glassCard(
      idx: 1,
      child: Row(
        children: [
          // Avatar
          Container(
            width: 58, height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(colors: [_AC.accent2, _AC.accent], begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: [BoxShadow(color: _AC.accent2.withOpacity(0.4), blurRadius: 15, spreadRadius: 1)],
            ),
            child: Center(
              child: Text(
                widget.username.substring(0, 1).toUpperCase(),
                style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(width: 16),
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.username, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 1, color: _AC.text), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 6),
                // Role badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: _AC.accent2.withOpacity(0.2),
                    border: Border.all(color: _AC.accent2.withOpacity(0.5)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _DynamicIcon(FontAwesomeIcons.shieldHalved, color: _AC.accent2, size: 10),
                      const SizedBox(width: 5),
                      Text(widget.role.toUpperCase(), style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: _AC.accent2)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Expiry
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _AC.glassBorder),
            ),
            child: Column(
              children: [
                const _DynamicIcon(FontAwesomeIcons.calendarDays, color: _AC.accent, size: 14),
                const SizedBox(height: 6),
                Text(widget.expiredDate, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.w700, color: _AC.text)),
                const SizedBox(height: 2),
                const Text('EXPIRY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 8, color: _AC.muted2, letterSpacing: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  TARGET CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildTargetCard() {
    return _glassCard(
      idx: 2,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.crosshairs, 'TARGET'),
          const SizedBox(height: 16),
          AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOutCubic,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(30), // Pill shape
              border: Border.all(
                color: _isTargetFocused ? _AC.accent : _AC.glassBorder,
                width: _isTargetFocused ? 1.5 : 1.0,
              ),
              boxShadow: _isTargetFocused ? [BoxShadow(color: _AC.accent.withOpacity(0.2), blurRadius: 12, spreadRadius: 1)] : null,
            ),
            child: Focus(
              onFocusChange: (f) => setState(() => _isTargetFocused = f),
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(6, 6, 0, 6),
                    child: Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _AC.accent.withOpacity(0.15),
                        border: Border.all(color: _AC.accent.withOpacity(0.3)),
                      ),
                      child: const Center(child: _DynamicIcon(FontAwesomeIcons.globe, color: _AC.accent, size: 18)),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: targetController,
                      keyboardType: TextInputType.phone,
                      style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 16, color: _AC.text, letterSpacing: 1),
                      cursorColor: _AC.accent,
                      cursorWidth: 2,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: '6283848446158',
                        hintStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 14, color: _AC.muted2),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                      onSubmitted: (_) => _sendBug(),
                    ),
                  ),
                  GestureDetector(
                    onTap: _pasteTarget,
                    child: Container(
                      margin: const EdgeInsets.all(6),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        color: _AC.surface.withOpacity(0.8),
                        border: Border.all(color: _AC.glassBorder),
                      ),
                      child: const Text('Copy', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, color: _AC.text)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  const _DynamicIcon(FontAwesomeIcons.circleInfo, color: _AC.muted2, size: 11),
                  const SizedBox(width: 6),
                  const Text('International format without +', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: _AC.muted2)),
                ]),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _AC.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _AC.accent.withOpacity(0.3)),
                  ),
                  child: const Text('62xxx', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _AC.accent)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUG ARSENAL CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBugArsenalCard() {
    return _glassCard(
      idx: 3,
      child: Column(
        children: [
          _buildSectionHeader(FontAwesomeIcons.spider, 'ARSENAL', tag: '${widget.listBug.length}'),
          const SizedBox(height: 16),
          SizedBox(
            height: 150,
            child: widget.listBug.isEmpty
                ? Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _AC.glassBorder),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const _DynamicIcon(FontAwesomeIcons.spider, color: _AC.muted2, size: 32),
                        const SizedBox(height: 12),
                        const Text('No bugs available', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12, color: _AC.muted2)),
                      ],
                    ),
                  )
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    itemCount: widget.listBug.length,
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final sel = selectedBugId == bug['bug_id'];
                      return GestureDetector(
                        onTap: () => setState(() => selectedBugId = bug['bug_id']),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOutCubic,
                          width: 160,
                          margin: const EdgeInsets.only(right: 12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: sel ? _AC.accent2.withOpacity(0.15) : Colors.black.withOpacity(0.2),
                            border: Border.all(
                              color: sel ? _AC.accent2 : _AC.glassBorder, 
                              width: sel ? 1.5 : 1.0
                            ),
                            boxShadow: sel ? [BoxShadow(color: _AC.accent2.withOpacity(0.2), blurRadius: 15, spreadRadius: 1)] : null,
                          ),
                          child: Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 46, height: 46,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        color: sel ? _AC.accent2.withOpacity(0.25) : Colors.white.withOpacity(0.05),
                                        border: Border.all(color: sel ? _AC.accent2.withOpacity(0.5) : Colors.white.withOpacity(0.1)),
                                      ),
                                      child: Center(child: _DynamicIcon(FontAwesomeIcons.skull, color: sel ? _AC.accent : _AC.muted, size: 22)),
                                    ),
                                    const Spacer(),
                                    Text(
                                      (bug['bug_name'] ?? '').toString().toUpperCase(),
                                      style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11, fontWeight: FontWeight.w700, color: _AC.text, letterSpacing: 0.5),
                                      maxLines: 1, overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 6),
                                    Row(children: [
                                      Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? _AC.success : _AC.muted2, boxShadow: sel ? [BoxShadow(color: _AC.success, blurRadius: 6)] : null)),
                                      const SizedBox(width: 6),
                                      Text('READY', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9, fontWeight: FontWeight.w700, color: sel ? _AC.success : _AC.muted2)),
                                    ]),
                                  ],
                                ),
                              ),
                              if (sel)
                                Positioned(
                                  top: 12, right: 12,
                                  child: Container(
                                    width: 24, height: 24,
                                    decoration: BoxDecoration(color: _AC.accent2, shape: BoxShape.circle, boxShadow: [BoxShadow(color: _AC.accent2.withOpacity(0.5), blurRadius: 8)]),
                                    child: const Icon(Icons.check, color: Colors.white, size: 14),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              widget.listBug.isEmpty ? 1 : (widget.listBug.length > 5 ? 5 : widget.listBug.length),
              (index) {
                final si = widget.listBug.indexWhere((b) => b['bug_id'] == selectedBugId);
                final active = si == index || (si > 4 && index == 4);
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  height: 4, width: active ? 24 : 8,
                  decoration: BoxDecoration(
                    color: active ? _AC.accent : _AC.muted2.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: active ? [BoxShadow(color: _AC.accent.withOpacity(0.5), blurRadius: 6)] : null,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  DEPLOY CARD
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildDeployCard() {
    return _glassCard(
      idx: 4,
      child: Column(
        children: [
          Row(children: [
            _buildSecIco(FontAwesomeIcons.server),
            const SizedBox(width: 12),
            const Text('DEPLOY', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2, color: _AC.text)),
            const Spacer(),
            GestureDetector(
              onTap: _isLoadingSenders ? null : _fetchSenderCounts,
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.black.withOpacity(0.3), border: Border.all(color: _AC.glassBorder)),
                child: Center(
                  child: _isLoadingSenders
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: _AC.accent))
                      : const _DynamicIcon(FontAwesomeIcons.rotate, color: _AC.muted2, size: 14),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _buildDeployOpt(icon: FontAwesomeIcons.userShield, title: 'PRIVATE', subtitle: 'Your Session', type: 'private', selColor: _AC.accent)),
              const SizedBox(width: 12),
              Expanded(child: _buildDeployOpt(icon: FontAwesomeIcons.globe, title: 'GLOBAL', subtitle: '$_globalSenderCount Active', type: 'global', selColor: _AC.accent2)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeployOpt({required dynamic icon, required String title, required String subtitle, required String type, required Color selColor}) {
    final sel = _senderType == type;
    final disabled = type == 'global' && !canUseGlobalSender;

    return GestureDetector(
      onTap: () {
        if (disabled) {
          _showAlert("Access Denied", "Global sender is only available for: Founder, VIP, Owner, High Owner, High Admin, Moderator, Dev");
          return;
        }
        setState(() => _senderType = type);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20), // Squircle
          color: sel ? selColor.withOpacity(0.15) : Colors.black.withOpacity(0.2),
          border: Border.all(color: sel ? selColor : _AC.glassBorder, width: sel ? 1.5 : 1.0),
          boxShadow: sel ? [BoxShadow(color: selColor.withOpacity(0.2), blurRadius: 15, spreadRadius: 1)] : null,
        ),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        child: Column(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: sel ? selColor.withOpacity(0.25) : Colors.white.withOpacity(0.05),
                border: Border.all(color: sel ? selColor.withOpacity(0.5) : Colors.white.withOpacity(0.1)),
              ),
              child: Center(child: _DynamicIcon(icon, color: disabled ? _AC.muted2 : sel ? selColor : _AC.muted, size: 20)),
            ),
            const SizedBox(height: 12),
            Text(title, style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: disabled ? _AC.muted2 : sel ? _AC.text : _AC.muted)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, color: _AC.muted2)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  LAUNCH BUTTON
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final pulse = _pulseController.value;
        return Container(
          width: double.infinity,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(31), // Pill
            boxShadow: [
              BoxShadow(color: _AC.accent3.withOpacity(0.3 + pulse * 0.15), blurRadius: 25, spreadRadius: 3),
              BoxShadow(color: _AC.accent.withOpacity(0.2), blurRadius: 15, spreadRadius: 1),
            ],
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(31),
              gradient: const LinearGradient(
                colors: [_AC.accent, _AC.accent2, _AC.accent3], 
                begin: Alignment.centerLeft, 
                end: Alignment.centerRight
              ),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(31),
                onTap: _isSending ? null : _sendBug,
                splashColor: Colors.white.withOpacity(0.1),
                highlightColor: Colors.white.withOpacity(0.05),
                child: Center(
                  child: _isSending
                      ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)),
                          const SizedBox(width: 16),
                          const Text('INJECTING', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 3, color: Colors.white)),
                        ])
                      : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const _DynamicIcon(FontAwesomeIcons.skull, color: Colors.white, size: 20),
                          const SizedBox(width: 12),
                          const Text('LAUNCH', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 3, color: Colors.white)),
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.all(4), 
                            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.2)), 
                            child: const Icon(Icons.keyboard_double_arrow_right, color: Colors.white, size: 16)
                          ),
                        ]),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STATUS BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildStatusBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _AC.glassBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _AC.glassBorder),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _AC.success, boxShadow: [BoxShadow(color: _AC.success, blurRadius: 8, spreadRadius: 1)])),
                const SizedBox(width: 8),
                const Text('SYSTEM ONLINE', style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.success, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            decoration: BoxDecoration(
              color: _AC.glassBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _AC.glassBorder),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _AC.accent, boxShadow: [BoxShadow(color: _AC.accent, blurRadius: 8, spreadRadius: 1)])),
                const SizedBox(width: 8),
                Text('${widget.listBug.length} BUGS', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, color: _AC.accent, letterSpacing: 1.5)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Shared Section Header + Icon Helper ──────────────────────────────
  Widget _buildSectionHeader(dynamic icon, String title, {String? tag}) {
    return Row(
      children: [
        _buildSecIco(icon),
        const SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 2, color: _AC.text)),
          const SizedBox(height: 4),
          Container(width: 30, height: 2, decoration: BoxDecoration(color: _AC.accent.withOpacity(0.5), borderRadius: BorderRadius.circular(1))),
        ]),
        if (tag != null) ...[
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: _AC.accent.withOpacity(0.15),
              border: Border.all(color: _AC.accent.withOpacity(0.3)),
            ),
            child: Text(tag, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.w700, color: _AC.accent, letterSpacing: 1)),
          ),
        ],
      ],
    );
  }

  Widget _buildSecIco(dynamic icon) {
    return Container(
      width: 44, height: 44,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _AC.accent.withOpacity(0.15),
        border: Border.all(color: _AC.accent.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: _AC.accent.withOpacity(0.1), blurRadius: 10)],
      ),
      child: Center(child: _DynamicIcon(icon, color: _AC.accent, size: 18)),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════
//  SUCCESS DIALOG (Glassmorphism style)
// ═════════════════════════════════════════════════════════════════════════
class _SuccessDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final VoidCallback onDismiss;

  const _SuccessDialog({required this.target, required this.senderType, required this.onDismiss});

  @override
  State<_SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<_SuccessDialog> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _infoController;
  late AnimationController _glowController;
  late AnimationController _ringController;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _infoController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _glowController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _ringController = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
    _scaleController.forward();
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) {
        _infoController.forward();
      }
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _infoController.dispose();
    _glowController.dispose();
    _ringController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width * 0.88;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ScaleTransition(
        scale: CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              width: w,
              constraints: const BoxConstraints(maxWidth: 380),
              decoration: BoxDecoration(
                color: _AC.glassBg,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _AC.glassBorder, width: 1.5),
                boxShadow: [
                  BoxShadow(color: _AC.accent3.withOpacity(0.2), blurRadius: 30, spreadRadius: 5),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
                child: FadeTransition(
                  opacity: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
                  child: ScaleTransition(
                    scale: CurvedAnimation(parent: _infoController, curve: Curves.easeOut),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedBuilder(
                          animation: _ringController,
                          builder: (ctx, _) {
                            return Container(
                              width: 90, height: 90,
                              padding: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.transparent,
                                border: Border.all(
                                  color: (widget.senderType == 'global' ? _AC.success : _AC.accent)
                                      .withOpacity(0.3 + _glowController.value * 0.2),
                                  width: 2.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: (widget.senderType == 'global' ? _AC.success : _AC.accent)
                                        .withOpacity(0.2 + _glowController.value * 0.1), 
                                    blurRadius: 20, spreadRadius: 2
                                  )
                                ],
                              ),
                              child: Container(
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: widget.senderType == 'global' 
                                        ? [_AC.success, const Color(0xFF1A9E4A)] 
                                        : [_AC.accent2, _AC.accent3],
                                  ),
                                ),
                                child: Center(
                                  child: _DynamicIcon(
                                    widget.senderType == 'global' ? FontAwesomeIcons.rocket : FontAwesomeIcons.dragon,
                                    color: Colors.white, size: 38,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 24),
                        Text(
                          widget.senderType == 'global' ? 'GLOBAL STRIKE!' : 'ATTACK SUCCESS',
                          style: const TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2, color: _AC.text),
                        ),
                        const SizedBox(height: 8),
                        Container(width: 40, height: 2, decoration: BoxDecoration(color: _AC.accent.withOpacity(0.5), borderRadius: BorderRadius.circular(1))),
                        const SizedBox(height: 20),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _AC.glassBorder),
                          ),
                          child: Column(
                            children: [
                              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const _DynamicIcon(FontAwesomeIcons.mobileScreen, color: _AC.muted, size: 16),
                                const SizedBox(width: 10),
                                Text(widget.target, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 16, fontWeight: FontWeight.w700, color: _AC.text)),
                              ]),
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: (widget.senderType == 'global' ? _AC.success : _AC.accent2).withOpacity(0.15),
                                  border: Border.all(color: (widget.senderType == 'global' ? _AC.success : _AC.accent2).withOpacity(0.3)),
                                ),
                                child: Text(widget.senderType.toUpperCase(), style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2, color: widget.senderType == 'global' ? _AC.success : _AC.accent2)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                        GestureDetector(
                          onTap: widget.onDismiss,
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: _AC.glassBorder),
                            ),
                            child: const Center(child: Text('CLOSE', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: _AC.text))),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════
//  CUSTOM PAINTER FOR TIMELINE ARC
// ═════════════════════════════════════════════════════════════════════════
class _ArcPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF9D00FF).withOpacity(0.3) // Electric Purple
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final path = Path();
    path.moveTo(0, size.height * 0.8);
    path.quadraticBezierTo(size.width * 0.5, -size.height * 0.2, size.width, size.height * 0.8);
    
    // Glow effect
    canvas.drawPath(path, Paint()..color = const Color(0xFF00E5FF).withOpacity(0.1)..style = PaintingStyle.stroke..strokeWidth = 6..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4));
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END